#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
TEAM="${APPLE_TEAM_ID:-}"
if ! command -v xcodebuild >/dev/null; then
  echo 'BLOCKED: A Mac with Xcode is required.' >&2; exit 2
fi
if [ -z "$TEAM" ]; then
  echo 'BLOCKED: Set APPLE_TEAM_ID to your Apple Developer Team ID (do NOT send certificates/private keys).' >&2; exit 3
fi
if ! /usr/libexec/PlistBuddy -c 'Print :com.apple.developer.carplay-audio' "$ROOT/src/כתר ראובן/Entitlements/Entitlements.plist" 2>/dev/null | grep -q '^true$'; then
  echo 'CarPlay Audio entitlement is not enabled in project source. Without Apple approval, an archive will not enable CarPlay.' >&2
  echo 'STOP: Obtain Apple approval and configure the Apple-issued capability and provisioning before making a CarPlay signed archive.' >&2
  exit 4
fi
mkdir -p "$ROOT/out"
xcodebuild -project "$ROOT/src/כתר ראובן.xcodeproj"   -scheme 'כתר ראובן' -configuration Release   -destination 'generic/platform=iOS'   -archivePath "$ROOT/out/KeterReuven-CarPlay.xcarchive"   -allowProvisioningUpdates   DEVELOPMENT_TEAM="$TEAM" CODE_SIGN_STYLE=Automatic archive
printf '%s\n' 'Archive built. Export to IPA only with a valid distribution identity/profile in Xcode Organizer.'
