#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
if [ "${CARPLAY_AUDIO_APPROVED:-}" != 'YES' ]; then
  echo 'BLOCKED: Apple must approve the CarPlay Audio managed capability for the exact App ID first.' >&2
  echo 'After approval, set CARPLAY_AUDIO_APPROVED=YES (only when true) and run again.' >&2
  exit 2
fi
PLIST="$ROOT/src/כתר ראובן/Entitlements/Entitlements.plist"
/usr/libexec/PlistBuddy -c 'Add :com.apple.developer.carplay-audio bool true' "$PLIST" ||   /usr/libexec/PlistBuddy -c 'Set :com.apple.developer.carplay-audio true' "$PLIST"
echo 'Configured project entitlement. Next confirm provision profile contains it, then archive.'
