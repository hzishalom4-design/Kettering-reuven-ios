#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PROJECT="$ROOT/src/כתר ראובן.xcodeproj"
SCHEME='כתר ראובן'
cd "$ROOT"
command -v xcodebuild >/dev/null || { echo 'BLOCKED: This script requires macOS with Xcode.' >&2; exit 2; }
echo '=== Xcode environment ==='
xcodebuild -version
mkdir -p "$ROOT/out"
echo '=== Available schemes ==='
xcodebuild -list -project "$PROJECT"
echo '=== Building unsigned iOS Simulator application ==='
xcodebuild -project "$PROJECT"   -scheme "$SCHEME" -configuration Debug   -sdk iphonesimulator   -destination 'generic/platform=iOS Simulator'   -derivedDataPath "$ROOT/.build-ios-simulator"   CODE_SIGNING_ALLOWED=NO build
APP_DIR="$ROOT/.build-ios-simulator/Build/Products/Debug-iphonesimulator"
APP_PATH="$(find "$APP_DIR" -maxdepth 1 -type d -name '*.app' -print -quit)"
[ -n "$APP_PATH" ] || { echo 'FAIL: .app not found after build.' >&2; exit 3; }
ditto -c -k --sequesterRsrc --keepParent "$APP_PATH" "$ROOT/out/KeterReuven-iOS-CarPlay-Simulator.app.zip"
echo "SUCCESS: $ROOT/out/KeterReuven-iOS-CarPlay-Simulator.app.zip"
echo 'This is a simulator-only unsigned application. It is NOT an iPhone/TestFlight IPA.'
