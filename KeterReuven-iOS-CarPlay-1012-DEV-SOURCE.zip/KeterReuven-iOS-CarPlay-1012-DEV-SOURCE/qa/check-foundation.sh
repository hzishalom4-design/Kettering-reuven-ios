#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
command -v swiftc >/dev/null || { echo 'Swift compiler not installed'; exit 2; }
find 'src/כתר ראובן' -name '*.swift' -print0 | xargs -0 swiftc -frontend -parse
swiftc -typecheck 'src/כתר ראובן/CarKit/KeterCarModels.swift' \
  'src/כתר ראובן/CarKit/KeterCarAPI.swift' \
  'src/כתר ראובן/CarKit/KeterPrayerBriefings.swift'
python3 - <<'PY'
import plistlib
from pathlib import Path
root=Path('src/כתר ראובן')
for name in ['Info.plist','Entitlements/Entitlements.plist','PrivacyInfo.xcprivacy']:
    plistlib.load(open(root/name,'rb'))
print('Swift parser, Foundation typechecker and plist checks: PASS')
PY
