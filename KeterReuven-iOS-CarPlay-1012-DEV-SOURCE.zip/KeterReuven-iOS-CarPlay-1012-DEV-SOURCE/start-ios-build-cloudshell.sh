#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")"
command -v gh >/dev/null || { echo 'GitHub CLI is required (gh).'; exit 2; }
command -v git >/dev/null || { echo 'git is required.'; exit 2; }
if ! gh auth status >/dev/null 2>&1; then
  echo 'Sign in to YOUR account only. Never send passwords/tokens to chat.'
  gh auth login --web --git-protocol https
fi
# Avoid creating a new repository or overwriting an existing iOS repository implicitly.
if ! git remote get-url origin >/dev/null 2>&1; then
  if [ -z "${CARPLAY_GITHUB_REPO:-}" ]; then
    echo 'NO REPOSITORY CHANGED. To build in your EXISTING GitHub repository:' >&2
    echo 'export CARPLAY_GITHUB_REPO=owner/existing-ios-repository' >&2
    echo 'bash start-ios-build-cloudshell.sh' >&2
    exit 3
  fi
  gh repo view "$CARPLAY_GITHUB_REPO" >/dev/null || { echo 'The supplied repository was not found.' >&2; exit 4; }
  if [ ! -d .git ]; then git init -b main; fi
  git remote add origin "https://github.com/${CARPLAY_GITHUB_REPO}.git"
fi
if [ -n "$(git status --porcelain 2>/dev/null)" ]; then
  git add .
  git -c user.name="$(gh api user --jq .login)" -c user.email="$(gh api user --jq .login)@users.noreply.github.com" \
    commit -m 'Prepare Keter Reuven CarPlay 1012 DEV source'
fi
printf '\nLocal source is prepared. Remote: %s\n' "$(git remote get-url origin)"
echo 'For an existing remote history, first merge this source into its existing iOS project.'
echo 'No automatic push is performed, to avoid overwriting an existing app repository.'
echo 'After review, run: git push -u origin main; then run GitHub Actions simulator build.'
