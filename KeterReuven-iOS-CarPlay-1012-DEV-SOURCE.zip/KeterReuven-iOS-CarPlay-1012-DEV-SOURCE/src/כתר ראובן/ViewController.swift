import UIKit
import WebKit

var webView: WKWebView! = nil

class ViewController: UIViewController, WKNavigationDelegate, UIDocumentInteractionControllerDelegate {
    enum LoadingMode {
        case defaultCachePolicy
        case forceCache
    }

    var documentController: UIDocumentInteractionController?
    func documentInteractionControllerViewControllerForPreview(_ controller: UIDocumentInteractionController) -> UIViewController {
        return self
    }
    
    @IBOutlet weak var loadingView: UIView!
    @IBOutlet weak var progressView: UIProgressView!
    @IBOutlet weak var connectionProblemView: UIImageView!
    @IBOutlet weak var webviewView: UIView!
    var toolbarView: UIToolbar!
    private let compassBridge = NativeCompassBridge()
    private let carAudioApi = KeterCarAPI()
    
    var htmlIsLoaded = false;
    private var loadingMode = LoadingMode.defaultCachePolicy
    
    private var themeObservation: NSKeyValueObservation?
    var currentWebViewTheme: UIUserInterfaceStyle = .unspecified
    override var preferredStatusBarStyle: UIStatusBarStyle {
        if #available(iOS 13.0, *), adaptiveUIStyle {
            switch currentWebViewTheme {
            case .dark:
                return .lightContent
            case .light:
                return .darkContent
            default:
                return .lightContent
            }
        }
        if overrideStatusBar {
            return statusBarTheme == "dark" ? .lightContent : .darkContent
        }
        return .default
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        initWebView()
        initToolbarView()
        loadRootUrl()
    
        NotificationCenter.default.addObserver(self, selector: #selector(self.keyboardWillHide(_:)), name: UIResponder.keyboardWillHideNotification , object: nil)
        
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        כתרראובן.webView.frame = calcWebviewFrame(webviewView: webviewView, toolbarView: nil)
        compassBridge.updateHeadingOrientation()
    }
    
    @objc func keyboardWillHide(_ notification: NSNotification) {
        כתרראובן.webView.setNeedsLayout()
    }
    
    func initWebView() {
        כתרראובן.webView = createWebView(container: webviewView, WKSMH: self, WKND: self)
        webviewView.addSubview(כתרראובן.webView);
        compassBridge.attach(to: כתרראובן.webView)
        
        כתרראובן.webView.uiDelegate = self;
        
        כתרראובן.webView.addObserver(self, forKeyPath: #keyPath(WKWebView.estimatedProgress), options: .new, context: nil)

        if(pullToRefresh){
            let refreshControl = UIRefreshControl()
            refreshControl.addTarget(self, action: #selector(refreshWebView(_:)), for: UIControl.Event.valueChanged)
            כתרראובן.webView.scrollView.addSubview(refreshControl)
            כתרראובן.webView.scrollView.bounces = true
        }

        if #available(iOS 15.0, *), adaptiveUIStyle {
            themeObservation = כתרראובן.webView.observe(\.themeColor) { [unowned self] webView, _ in
                let backgroundColor = כתרראובן.webView.underPageBackgroundColor;
                let themeColor = כתרראובן.webView.themeColor;
                currentWebViewTheme = themeColor?.isLight() ?? backgroundColor?.isLight() ?? true ? .light : .dark
                self.overrideUIStyle()
                self.setNeedsStatusBarAppearanceUpdate()
                view.backgroundColor = themeColor ?? backgroundColor;
            }
        }
    }

    @objc func refreshWebView(_ sender: UIRefreshControl) {
        כתרראובן.webView?.reload()
        sender.endRefreshing()
    }

    func createToolbarView() -> UIToolbar{
        let winScene = UIApplication.shared.connectedScenes.first
        let windowScene = winScene as! UIWindowScene
        var statusBarHeight = windowScene.statusBarManager?.statusBarFrame.height ?? 60
        
        #if targetEnvironment(macCatalyst)
        if (statusBarHeight == 0){
            statusBarHeight = 30
        }
        #endif
        
        let toolbarView = UIToolbar(frame: CGRect(x: 0, y: 0, width: webviewView.frame.width, height: 0))
        toolbarView.sizeToFit()
        toolbarView.frame = CGRect(x: 0, y: 0, width: webviewView.frame.width, height: toolbarView.frame.height + statusBarHeight)
//        toolbarView.autoresizingMask = [.flexibleTopMargin, .flexibleRightMargin, .flexibleWidth]
        
        let flex = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        let close = UIBarButtonItem(barButtonSystemItem: .done, target: self, action: #selector(loadRootUrl))
        toolbarView.setItems([close,flex], animated: true)
        
        toolbarView.isHidden = true
        
        return toolbarView
    }
    
    func overrideUIStyle(toDefault: Bool = false) {
        if #available(iOS 15.0, *), adaptiveUIStyle {
            if (((htmlIsLoaded && !כתרראובן.webView.isHidden) || toDefault) && self.currentWebViewTheme != .unspecified) {
                UIApplication
                    .shared
                    .connectedScenes
                    .flatMap { ($0 as? UIWindowScene)?.windows ?? [] }
                    .first { $0.isKeyWindow }?.overrideUserInterfaceStyle = toDefault ? .unspecified : self.currentWebViewTheme;
            }
        }
    }
    
    func initToolbarView() {
        toolbarView =  createToolbarView()
        
        webviewView.addSubview(toolbarView)
    }
    
    @objc func loadRootUrl(cachePolicy: NSURLRequest.CachePolicy = .useProtocolCachePolicy) {
        כתרראובן.webView.load(URLRequest(url: SceneDelegate.universalLinkToLaunch ?? SceneDelegate.shortcutLinkToLaunch ?? rootUrl, cachePolicy: cachePolicy))
    }
    
    func reloadWebview(
        loadingMode: LoadingMode = LoadingMode.defaultCachePolicy
    ) {
        switch loadingMode {
        case LoadingMode.defaultCachePolicy:
            loadRootUrl(cachePolicy: .useProtocolCachePolicy);

        case LoadingMode.forceCache:
            loadRootUrl(cachePolicy: .useProtocolCachePolicy);
        }

        self.loadingMode = loadingMode
    }
    
    func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
        compassBridge.reset()
    }

    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!){
        htmlIsLoaded = true
        
        self.setProgress(1.0, true)
        self.animateConnectionProblem(false)
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.8) {
            כתרראובן.webView.isHidden = false
            self.loadingView.isHidden = true
           
            self.setProgress(0.0, false)
            
            self.overrideUIStyle()
        }
    }
    
    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
        htmlIsLoaded = false;
        
        if (error as NSError).code == (-999) { return }
        if (error as NSError).code == 102 { return }
        
        self.overrideUIStyle(toDefault: true);
        webView.isHidden = true;
        loadingView.isHidden = false;

        if loadingMode == LoadingMode.defaultCachePolicy {
            DispatchQueue.main.async {
                self.reloadWebview(loadingMode: LoadingMode.forceCache)
            }
        } else {
            animateConnectionProblem(true);
            setProgress(0.05, true);
            
            DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
                self.setProgress(0.1, true);
                DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
                    self.reloadWebview()
                }
            }
        }
    }
    
    override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {

        if (keyPath == #keyPath(WKWebView.estimatedProgress) &&
                כתרראובן.webView.isLoading &&
                !self.loadingView.isHidden &&
                !self.htmlIsLoaded) {
                    var progress = Float(כתרראובן.webView.estimatedProgress);
                    
                    if (progress >= 0.8) { progress = 1.0; };
                    if (progress >= 0.3) { self.animateConnectionProblem(false); }
                    
                    self.setProgress(progress, true);
        }
    }
    
    func setProgress(_ progress: Float, _ animated: Bool) {
        self.progressView.setProgress(progress, animated: animated);
    }
    
    
    func animateConnectionProblem(_ show: Bool) {
        if (show) {
            self.connectionProblemView.isHidden = false;
            self.connectionProblemView.alpha = 0
            UIView.animate(withDuration: 0.7, delay: 0, options: [.repeat, .autoreverse], animations: {
                self.connectionProblemView.alpha = 1
            })
        }
        else {
            UIView.animate(withDuration: 0.3, delay: 0, options: [], animations: {
                self.connectionProblemView.alpha = 0 // Here you will get the animation you want
            }, completion: { _ in
                self.connectionProblemView.isHidden = true;
                self.connectionProblemView.layer.removeAllAnimations();
            })
        }
    }
        
    deinit {
        כתרראובן.webView.removeObserver(self, forKeyPath: #keyPath(WKWebView.estimatedProgress))
    }
}

extension UIColor {
    // Check if the color is light or dark, as defined by the injected lightness threshold.
    // Some people report that 0.7 is best. I suggest to find out for yourself.
    // A nil value is returned if the lightness couldn't be determined.
    func isLight(threshold: Float = 0.5) -> Bool? {
        let originalCGColor = self.cgColor

        // Now we need to convert it to the RGB colorspace. UIColor.white / UIColor.black are greyscale and not RGB.
        // If you don't do this then you will crash when accessing components index 2 below when evaluating greyscale colors.
        let RGBCGColor = originalCGColor.converted(to: CGColorSpaceCreateDeviceRGB(), intent: .defaultIntent, options: nil)
        guard let components = RGBCGColor?.components else {
            return nil
        }
        guard components.count >= 3 else {
            return nil
        }

        let brightness = Float(((components[0] * 299) + (components[1] * 587) + (components[2] * 114)) / 1000)
        return (brightness > threshold)
    }
}

extension ViewController: WKScriptMessageHandler {
  func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        if message.name == "kr-car-audio" {
            handleCarAudioMessage(message)
            return
        }
        if message.name == "kr-native-compass" {
            compassBridge.handle(message)
            return
        }
        if message.name == "print" {
            printView(webView: כתרראובן.webView)
        }
        if message.name == "push-subscribe" {
            handleSubscribeTouch(message: message)
        }
        if message.name == "push-permission-request" {
            handlePushPermission()
        }
        if message.name == "push-permission-state" {
            handlePushState()
        }
        if message.name == "push-token" {
            handlePushToken()
        }
        if message.name == "share" {
            presentNativeShare(message: message)
        }
  }
}

extension ViewController {
    func presentNativeShare(message: WKScriptMessage) {
        var payload: [String: Any] = [:]
        if let dict = message.body as? [String: Any] {
            payload = dict
        } else if let body = message.body as? String,
                  let data = body.data(using: .utf8),
                  let object = try? JSONSerialization.jsonObject(with: data),
                  let dict = object as? [String: Any] {
            payload = dict
        }

        var items: [Any] = []
        let title = (payload["title"] as? String ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        let text = (payload["text"] as? String ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        let urlString = (payload["url"] as? String ?? "").trimmingCharacters(in: .whitespacesAndNewlines)

        if !text.isEmpty { items.append(text) }
        else if !title.isEmpty { items.append(title) }
        if let url = URL(string: urlString), !urlString.isEmpty { items.append(url) }
        guard !items.isEmpty else { return }

        let controller = UIActivityViewController(activityItems: items, applicationActivities: nil)
        if let popover = controller.popoverPresentationController {
            popover.sourceView = view
            popover.sourceRect = CGRect(x: view.bounds.midX, y: view.bounds.midY, width: 1, height: 1)
            popover.permittedArrowDirections = []
        }
        present(controller, animated: true)
    }
}

// Opt-in handoff: site player -> same AVPlayer/CarPlay media session.
// Strict origin and opaque ID checks. A call is made only by the website UI.
extension ViewController {
    func handleCarAudioMessage(_ message: WKScriptMessage) {
        guard message.frameInfo.isMainFrame,
              message.frameInfo.securityOrigin.protocol == "https",
              message.frameInfo.securityOrigin.host == "www.keter-reuven.co.il",
              let payload = message.body as? [String: Any],
              let type = payload["type"] as? String,
              let id = payload["id"] as? String,
              let requestId = payload["requestId"] as? String,
              requestId.range(of: "^[A-Za-z0-9-]{8,40}$", options: .regularExpression) != nil else { return }

        let actions = Set(["play", "radio", "pause", "resume", "next", "previous", "status"])
        guard actions.contains(type) else {
            respondToCarAudio(requestId, ok: false, value: "INVALID_COMMAND")
            return
        }
        if type == "play" {
            guard id.range(of: "^[a-f0-9]{24}$", options: .regularExpression) != nil else {
                respondToCarAudio(requestId, ok: false, value: "INVALID_ID")
                return
            }
        } else if !id.isEmpty {
            respondToCarAudio(requestId, ok: false, value: "INVALID_COMMAND")
            return
        }

        if type == "play" || type == "radio" {
            Task { @MainActor in
                do {
                    let episodes = try await carAudioApi.recordings()
                    // A valid-looking ID is not sufficient. It MUST be in our verified catalog.
                    if type == "play" {
                        guard let episode = episodes.first(where: { $0.id == id }) else {
                            respondToCarAudio(requestId, ok: false, value: "UNKNOWN_MEDIA_ID")
                            return
                        }
                        try KeterAudioPlayer.shared.play(episode, from: episodes)
                    } else {
                        try KeterAudioPlayer.shared.playRadio(episodes)
                    }
                    respondToCarAudio(requestId, ok: true, value: "accepted")
                } catch {
                    respondToCarAudio(requestId, ok: false, value: "PLAYER_UNAVAILABLE")
                }
            }
            return
        }
        let player = KeterAudioPlayer.shared
        switch type {
        case "pause": player.pause()
        case "resume": player.play()
        case "next": player.next()
        case "previous": player.previous()
        default: break
        }
        respondToCarAudio(requestId, ok: true, value: type == "status" ? player.playbackStatus : "accepted")
    }

    private func respondToCarAudio(_ requestId: String, ok: Bool, value: String) {
        // Responses are delivered only while the current top-level document is trusted.
        guard let url = כתרראובן.webView?.url,
              url.scheme == "https", url.host == "www.keter-reuven.co.il" else { return }
        let response: [String: Any] = ["requestId": requestId, "ok": ok, "value": value]
        guard let data = try? JSONSerialization.data(withJSONObject: response),
              let json = String(data: data, encoding: .utf8) else { return }
        כתרראובן.webView.evaluateJavaScript(
            "window.__krCarAudioReceive && window.__krCarAudioReceive(\(json));",
            completionHandler: nil)
    }
}
