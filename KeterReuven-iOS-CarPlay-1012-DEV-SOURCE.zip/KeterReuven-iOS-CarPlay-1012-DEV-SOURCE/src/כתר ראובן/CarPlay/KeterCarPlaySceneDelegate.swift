import UIKit
import CarPlay

/// CarPlay audio scene in the existing iPhone app. Requires Apple's approved CarPlay Audio
/// capability on this App ID and its matching provisioning profile before device installation.
final class KeterCarPlaySceneDelegate: UIResponder, CPTemplateApplicationSceneDelegate {
    private weak var controller: CPInterfaceController?
    private var catalog: [KeterEpisode] = []
    private let api = KeterCarAPI()
    private var prayerTab: CPListTemplate?
    private var generation = 0

    func templateApplicationScene(_ scene: CPTemplateApplicationScene,
                                  didConnect interfaceController: CPInterfaceController) {
        controller = interfaceController
        generation += 1
        let currentGeneration = generation
        let loading = CPListItem(text: "טוען ספריית שיעורים…", detailText: "כתר ראובן")
        interfaceController.setRootTemplate(
            CPListTemplate(title: "כתר ראובן", sections: [CPListSection(items: [loading])]),
            animated: false, completion: nil)
        Task { @MainActor in
            await refreshCatalog(generation: currentGeneration)
        }
    }

    func templateApplicationScene(_ scene: CPTemplateApplicationScene,
                                  didDisconnect interfaceController: CPInterfaceController) {
        // Do not kill audio playback when a phone/car link is lost.
        generation += 1
        controller = nil
        prayerTab = nil
    }

    @MainActor private func refreshCatalog(generation requestGeneration: Int) async {
        do {
            catalog = try await api.recordings()
        } catch {
            // The prayer briefings should still work even if the recording feed is down.
            catalog = []
        }
        guard controller != nil, requestGeneration == generation else { return }
        installTabs()
        Task { @MainActor in await refreshPrayerTab(generation: requestGeneration) }
    }

    @MainActor private func installTabs() {
        guard let controller else { return }
        let recordings = CPListTemplate(title: "שיעורים מוקלטים",
                                        sections: [CPListSection(items: recordingHomeRows())])
        recordings.tabTitle = "שיעורים מוקלטים"
        let prayerLoading = CPListItem(text: "זמני תפילות — עדכון קולי", detailText: "טוען לוח מאומת")
        let prayers = CPListTemplate(title: "זמני תפילות",
                                     sections: [CPListSection(items: [prayerLoading])])
        prayers.tabTitle = "זמני תפילות"
        prayerTab = prayers
        let tabs = CPTabBarTemplate(templates: [recordings, prayers])
        controller.setRootTemplate(tabs, animated: false, completion: nil)
    }

    @MainActor private func recordingHomeRows() -> [CPListItem] {
        var rows: [CPListItem] = []
        if !catalog.isEmpty {
            let radio = CPListItem(text: "רדיו כתר ראובן – ברצף", detailText: "הפעלה ישירה של הקלטות")
            radio.handler = { [weak self] _, done in
                done()
                Task { @MainActor in
                    guard let self else { return }
                    do {
                        try KeterAudioPlayer.shared.playRadio(self.catalog)
                        self.showNowPlaying()
                    } catch { NSLog("Keter CarPlay radio failed: %@", String(describing: error)) }
                }
            }
            rows.append(radio)
            if KeterAudioPlayer.shared.canResume(from: catalog) {
                let resume = CPListItem(text: "המשך האזנה", detailText: "מהנקודה האחרונה")
                resume.handler = { [weak self] _, done in
                    done()
                    Task { @MainActor in
                        guard let self else { return }
                        do {
                            try KeterAudioPlayer.shared.resumeLast(from: self.catalog)
                            self.showNowPlaying()
                        } catch { NSLog("Keter CarPlay resume failed: %@", String(describing: error)) }
                    }
                }
                rows.append(resume)
            }
            let all = CPListItem(text: "כל השיעורים לפי תאריך", detailText: "מהחדש לישן")
            all.handler = { [weak self] _, done in
                done()
                Task { @MainActor in self?.showEpisodePage(self?.catalog ?? [], title: "כל השיעורים לפי תאריך", offset: 0) }
            }
            rows.append(all)
        }
        let groups = Dictionary(grouping: catalog, by: { $0.effectiveRabbi })
        let names = groups.keys.sorted {
            if $0 == "שיעורים נוספים" { return false }
            if $1 == "שיעורים נוספים" { return true }
            return $0.compare($1, locale: Locale(identifier: "he_IL")) == .orderedAscending
        }
        let available = max(1, CPListTemplate.maximumItemCount - rows.count - 1)
        for name in names.prefix(available) {
            let episodes = groups[name] ?? []
            let row = CPListItem(text: name, detailText: "\(episodes.count) שיעורים")
            if let art = episodes.first?.imageUrl { loadImage(art, into: row) }
            row.handler = { [weak self] _, done in
                done()
                Task { @MainActor in self?.showEpisodePage(episodes, title: name, offset: 0, allowPlayAll: true) }
            }
            rows.append(row)
        }
        if names.count > available {
            let remaining = Array(names.dropFirst(available))
            let more = CPListItem(text: "עוד רבנים", detailText: "\(remaining.count) תיקיות נוספות")
            more.handler = { [weak self] _, done in
                done()
                Task { @MainActor in self?.showMoreRabbis(remaining, groups: groups, offset: 0) }
            }
            rows.append(more)
        }
        if rows.isEmpty {
            let reload = CPListItem(text: "לא נמצאו שיעורים", detailText: "לחץ לניסיון חוזר")
            reload.handler = { [weak self] _, done in
                done()
                Task { @MainActor in
                    guard let self else { return }
                    await self.refreshCatalog(generation: self.generation)
                }
            }
            rows = [reload]
        }
        return rows
    }

    @MainActor private func showMoreRabbis(_ names: [String],
                                             groups: [String: [KeterEpisode]], offset: Int) {
        guard let controller else { return }
        let pageSize = max(1, min(20, CPListTemplate.maximumItemCount - 1))
        let segment = Array(names.dropFirst(offset).prefix(pageSize))
        var rows: [CPListItem] = segment.map { name in
            let episodes = groups[name] ?? []
            let item = CPListItem(text: name, detailText: "\(episodes.count) שיעורים")
            if let art = episodes.first?.imageUrl { loadImage(art, into: item) }
            item.handler = { [weak self] _, done in
                done()
                Task { @MainActor in self?.showEpisodePage(episodes, title: name, offset: 0, allowPlayAll: true) }
            }
            return item
        }
        if offset + segment.count < names.count {
            let more = CPListItem(text: "עוד רבנים", detailText: nil)
            more.handler = { [weak self] _, done in
                done()
                Task { @MainActor in self?.replaceCurrentPage {
                    self?.showMoreRabbis(names, groups: groups, offset: offset + segment.count)
                }}
            }
            rows.append(more)
        }
        controller.pushTemplate(CPListTemplate(title: "רבנים", sections: [CPListSection(items: rows)]),
                                animated: true, completion: nil)
    }

    @MainActor private func showEpisodePage(_ episodes: [KeterEpisode], title: String, offset: Int,
                                             allowPlayAll: Bool = false) {
        guard let controller else { return }
        let cap = max(1, min(20, CPListTemplate.maximumItemCount - 2))
        let segment = Array(episodes.dropFirst(offset).prefix(cap))
        var rows: [CPListItem] = []
        if allowPlayAll && offset == 0 && !episodes.isEmpty {
            let playAll = CPListItem(text: "השמעת כל שיעורי הרב ברצף", detailText: title)
            playAll.handler = { [weak self] _, done in
                done()
                Task { @MainActor in
                    guard let self else { return }
                    do {
                        try KeterAudioPlayer.shared.playRadio(episodes)
                        self.showNowPlaying()
                    } catch { NSLog("Keter CarPlay play-all failed: %@", String(describing: error)) }
                }
            }
            rows.append(playAll)
        }
        for episode in segment {
            let detail = [episode.effectiveRabbi, episode.dateLabel].filter { !$0.isEmpty }.joined(separator: " · ")
            let row = CPListItem(text: episode.title, detailText: detail)
            if let art = episode.imageUrl { loadImage(art, into: row) }
            row.handler = { [weak self] _, done in
                done()
                Task { @MainActor in
                    guard let self else { return }
                    do {
                        try KeterAudioPlayer.shared.play(episode, from: episodes)
                        self.showNowPlaying()
                    } catch { NSLog("Keter CarPlay lesson failed: %@", String(describing: error)) }
                }
            }
            rows.append(row)
        }
        if offset + segment.count < episodes.count {
            let more = CPListItem(text: "שיעורים קודמים", detailText: "\(episodes.count - offset - segment.count) נוספים")
            more.handler = { [weak self] _, done in
                done()
                Task { @MainActor in self?.replaceCurrentPage {
                    self?.showEpisodePage(episodes, title: title, offset: offset + segment.count,
                                          allowPlayAll: allowPlayAll)
                }}
            }
            rows.append(more)
        }
        if rows.isEmpty { rows = [CPListItem(text: "אין שיעורים זמינים", detailText: nil)] }
        controller.pushTemplate(CPListTemplate(title: title, sections: [CPListSection(items: rows)]),
                                animated: true, completion: nil)
    }

    /// Replace paginated list in-place instead of nesting dozens of templates.
    @MainActor private func replaceCurrentPage(_ build: @escaping () -> Void) {
        controller?.popTemplate(animated: false, completion: { _, _ in
            Task { @MainActor in build() }
        })
    }

    @MainActor private func showNowPlaying() {
        guard let controller else { return }
        controller.pushTemplate(CPNowPlayingTemplate.shared, animated: true, completion: nil)
    }

    @MainActor private func loadImage(_ url: URL, into item: CPListItem) {
        Task { @MainActor in
            do {
                var req = URLRequest(url: url)
                req.timeoutInterval = 5
                let (data, response) = try await URLSession.shared.data(for: req)
                guard let response = response as? HTTPURLResponse, response.statusCode == 200,
                      data.count < 650_000, let image = UIImage(data: data) else { return }
                item.setImage(image)
            } catch { /* retain placeholder */ }
        }
    }

    @MainActor private func refreshPrayerTab(generation requestGeneration: Int) async {
        let snapshot = await KeterPrayerService.shared.snapshot()
        guard controller != nil, requestGeneration == generation, let prayerTab else { return }
        let next = CPListItem(text: "התפילה הקרובה – \(snapshot.nextLabel)", detailText: snapshot.nextDetail)
        next.handler = { [weak self] _, done in
            done()
            Task { @MainActor in
                guard let self else { return }
                let fresh = await KeterPrayerService.shared.snapshot()
                await self.speak(fresh.narration(all: false), title: "התפילה הקרובה")
            }
        }
        let all = CPListItem(text: "כל תפילות היום – הקראה", detailText: "עדכון קולי לפי האתר")
        all.handler = { [weak self] _, done in
            done()
            Task { @MainActor in
                guard let self else { return }
                let fresh = await KeterPrayerService.shared.snapshot()
                await self.speak(fresh.narration(all: true), title: "כל תפילות היום")
            }
        }
        var items = [next, all]
        let maxRows = max(0, CPListTemplate.maximumItemCount - 2)
        for prayer in snapshot.rows.prefix(maxRows) {
            let row = CPListItem(text: "\(prayer.name) · \(prayer.time)", detailText: "הקראת שעת התפילה")
            row.handler = { [weak self] _, done in
                done()
                Task { @MainActor in
                    guard let self else { return }
                    let current = await KeterPrayerService.shared.snapshot()
                    guard let match = current.rows.first(where: { $0.name == prayer.name && $0.time == prayer.time }) else {
                        await self.speak("לוח התפילות השתנה. יש לטעון מחדש את זמני התפילות.", title: "עדכון זמני תפילות")
                        return
                    }
                    await self.speak("כתר ראובן, \(match.name), \(KeterPrayerService.spoken(match.time)).", title: match.name)
                }
            }
            items.append(row)
        }
        prayerTab.updateSections([CPListSection(items: items)])
    }

    @MainActor private func speak(_ text: String, title: String) async {
        do {
            let url = try await KeterSpeechWriter.shared.makeAudio(text)
            guard controller != nil else { return }
            try KeterAudioPlayer.shared.playBriefing(url, title: title)
            showNowPlaying()
        } catch {
            NSLog("Keter CarPlay Hebrew prayer briefing failed: %@", String(describing: error))
        }
    }
}
