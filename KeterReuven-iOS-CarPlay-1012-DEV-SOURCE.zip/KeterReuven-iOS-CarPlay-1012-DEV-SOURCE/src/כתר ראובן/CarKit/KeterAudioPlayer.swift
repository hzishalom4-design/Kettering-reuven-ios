import Foundation
import AVFoundation
import MediaPlayer
import UIKit

/// Single player for iPhone + CarPlay (when included in the existing native iOS app target).
/// Playback position is local until a user-authenticated cross-platform sync is implemented.
@MainActor
final class KeterAudioPlayer {
    static let shared = KeterAudioPlayer()
    private var player: AVPlayer?
    private var endObserver: NSObjectProtocol?
    private var positionObserver: Any?
    private var item: KeterEpisode?
    private var briefingTitle: String?
    private var queue: [KeterEpisode] = []
    private var index: Int = 0
    // Radio is a playlist of existing recordings. No fake live-stream claim.
    private var isRadioMode = false
    private let progress = UserDefaults.standard
    private var lifecycleObservers: [NSObjectProtocol] = []

    private init() {
        let remote = MPRemoteCommandCenter.shared()
        remote.playCommand.addTarget { [weak self] _ in
            Task { @MainActor in self?.play() }
            return .success
        }
        remote.pauseCommand.addTarget { [weak self] _ in
            Task { @MainActor in self?.pause() }
            return .success
        }
        remote.nextTrackCommand.addTarget { [weak self] _ in
            Task { @MainActor in self?.next() }
            return .success
        }
        remote.previousTrackCommand.addTarget { [weak self] _ in
            Task { @MainActor in self?.previous() }
            return .success
        }
        remote.skipForwardCommand.preferredIntervals = [30]
        remote.skipForwardCommand.addTarget { [weak self] _ in
            Task { @MainActor in self?.seekBy(30) }
            return .success
        }
        remote.skipBackwardCommand.preferredIntervals = [15]
        remote.skipBackwardCommand.addTarget { [weak self] _ in
            Task { @MainActor in self?.seekBy(-15) }
            return .success
        }
        // A car can disconnect or an incoming call can interrupt playback at any time.
        // Preserve the checkpoint without starting unsolicited playback afterwards.
        lifecycleObservers.append(NotificationCenter.default.addObserver(
            forName: UIApplication.didEnterBackgroundNotification, object: nil, queue: .main
        ) { [weak self] _ in
            Task { @MainActor in self?.savePosition() }
        })
        lifecycleObservers.append(NotificationCenter.default.addObserver(
            forName: AVAudioSession.interruptionNotification, object: nil, queue: .main
        ) { [weak self] note in
            guard let number = note.userInfo?[AVAudioSessionInterruptionTypeKey] as? UInt,
                  AVAudioSession.InterruptionType(rawValue: number) == .began else { return }
            Task { @MainActor in self?.pause() }
        })
        lifecycleObservers.append(NotificationCenter.default.addObserver(
            forName: AVAudioSession.routeChangeNotification, object: nil, queue: .main
        ) { [weak self] note in
            guard let number = note.userInfo?[AVAudioSessionRouteChangeReasonKey] as? UInt,
                  AVAudioSession.RouteChangeReason(rawValue: number) == .oldDeviceUnavailable else { return }
            Task { @MainActor in self?.pause() }
        })
    }

    func play(_ episode: KeterEpisode, from playlist: [KeterEpisode]) throws {
        isRadioMode = false
        try startEpisode(episode, from: playlist)
    }

    func playRadio(_ recordings: [KeterEpisode]) throws {
        guard let first = recordings.first(where: { $0.safeAudioURL != nil }) else {
            throw KeterCarError.unavailable
        }
        isRadioMode = true
        try startEpisode(first, from: recordings)
    }

    private func startEpisode(_ episode: KeterEpisode, from playlist: [KeterEpisode]) throws {
        guard let audioURL = episode.safeAudioURL else { throw KeterCarError.unavailable }
        savePosition()
        removeObservers()
        queue = playlist.filter { $0.safeAudioURL != nil }
        if !queue.contains(episode) { queue.insert(episode, at: 0) }
        index = queue.firstIndex(of: episode) ?? 0
        item = episode
        briefingTitle = nil
        progress.set(episode.id, forKey: "kr.car.last")
        try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default)
        try AVAudioSession.sharedInstance().setActive(true)
        let avItem = AVPlayerItem(url: audioURL)
        let newPlayer = AVPlayer(playerItem: avItem)
        player?.pause()
        player = newPlayer
        let seconds = progress.double(forKey: "kr.car.progress." + episode.id)
        if seconds > 0 && seconds.isFinite {
            newPlayer.seek(to: CMTime(seconds: seconds, preferredTimescale: 1000))
        }
        endObserver = NotificationCenter.default.addObserver(forName: .AVPlayerItemDidPlayToEndTime,
             object: avItem, queue: .main) { [weak self] _ in
            Task { @MainActor in self?.advanceAfterCompletion() }
        }
        positionObserver = newPlayer.addPeriodicTimeObserver(forInterval: CMTime(seconds: 10, preferredTimescale: 1),
             queue: .main) { [weak self] _ in
            Task { @MainActor in self?.savePosition(); self?.updateNowPlaying() }
        }
        newPlayer.play()
        updateNowPlaying()
    }

    /// A real audio briefing, not a non-audio CarPlay menu workaround.
    /// CarPlay and steering-wheel controls work through the same AVPlayer session.
    func playBriefing(_ file: URL, title: String) throws {
        guard file.isFileURL, FileManager.default.fileExists(atPath: file.path) else {
            throw KeterCarError.unavailable
        }
        savePosition()
        removeObservers()
        queue = []; index = 0; isRadioMode = false
        item = nil; briefingTitle = title
        try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default)
        try AVAudioSession.sharedInstance().setActive(true)
        let newItem = AVPlayerItem(url: file)
        let newPlayer = AVPlayer(playerItem: newItem)
        player?.pause(); player = newPlayer
        endObserver = NotificationCenter.default.addObserver(forName: .AVPlayerItemDidPlayToEndTime,
            object: newItem, queue: .main) { [weak self] _ in
            Task { @MainActor in self?.pause() }
        }
        positionObserver = newPlayer.addPeriodicTimeObserver(forInterval: CMTime(seconds: 1, preferredTimescale: 1),
            queue: .main) { [weak self] _ in
            Task { @MainActor in self?.updateNowPlaying() }
        }
        newPlayer.play()
        updateNowPlaying()
    }

    func resumeLast(from catalog: [KeterEpisode]) throws {
        guard let id = progress.string(forKey: "kr.car.last"),
              let episode = catalog.first(where: { $0.id == id }) else { throw KeterCarError.unavailable }
        try startEpisode(episode, from: catalog)
    }

    func canResume(from catalog: [KeterEpisode]) -> Bool {
        guard let id = progress.string(forKey: "kr.car.last"),
              catalog.contains(where: { $0.id == id }) else { return false }
        return progress.double(forKey: "kr.car.progress." + id) > 0
    }

    func seekBy(_ seconds: Double) {
        guard let player else { return }
        let current = player.currentTime().seconds
        guard current.isFinite else { return }
        let duration = player.currentItem?.duration.seconds ?? .infinity
        let target = max(0, min(current + seconds, duration.isFinite ? duration : current + max(0, seconds)))
        player.seek(to: CMTime(seconds: target, preferredTimescale: 1000))
        updateNowPlaying()
    }

    var playbackStatus: String {
        guard let player else { return "idle" }
        if player.timeControlStatus == .waitingToPlayAtSpecifiedRate { return "buffering" }
        return player.rate > 0 ? "playing" : "paused"
    }

    func play() { player?.play(); updateNowPlaying() }
    func pause() { savePosition(); player?.pause(); updateNowPlaying() }

    /// At completion, do not persist a seek position at the end of the old episode.
    /// `next()` may save the old position while switching, so clear it afterwards.
    private func advanceAfterCompletion() {
        let completedId = item?.id
        // A selected lesson stops at the end of the playlist.
        // An explicitly selected radio playlist wraps to the first recording.
        if index + 1 < queue.count {
            try? startEpisode(queue[index + 1], from: queue)
        } else if isRadioMode, let first = queue.first {
            try? startEpisode(first, from: queue)
        } else {
            pause()
        }
        if let completedId {
            progress.removeObject(forKey: "kr.car.progress." + completedId)
        }
    }

    func next() {
        if briefingTitle != nil { seekBy(30); return }
        if index + 1 < queue.count {
            try? startEpisode(queue[index + 1], from: queue)
        } else if isRadioMode, let first = queue.first {
            try? startEpisode(first, from: queue)
        } else {
            pause()
        }
    }
    func previous() {
        if briefingTitle != nil { seekBy(-15); return }
        guard index > 0 else {
            player?.seek(to: .zero)
            updateNowPlaying()
            return
        }
        try? startEpisode(queue[index - 1], from: queue)
    }

    private func savePosition() {
        guard let id = item?.id, let seconds = player?.currentTime().seconds,
              seconds.isFinite, seconds >= 0 else { return }
        progress.set(seconds, forKey: "kr.car.progress." + id)
    }
    private func updateNowPlaying() {
        guard let episode = item, briefingTitle == nil else {
            if let briefingTitle {
                let seconds = player?.currentTime().seconds ?? 0
                MPNowPlayingInfoCenter.default().nowPlayingInfo = [
                    MPMediaItemPropertyTitle: briefingTitle,
                    MPMediaItemPropertyArtist: "כתר ראובן",
                    MPNowPlayingInfoPropertyElapsedPlaybackTime: seconds.isFinite ? max(0, seconds) : 0,
                    MPNowPlayingInfoPropertyPlaybackRate: player?.rate ?? 0
                ]
            }
            return
        }
        let seconds = player?.currentTime().seconds ?? 0
        var info: [String: Any] = [
            MPMediaItemPropertyTitle: episode.title,
            MPMediaItemPropertyArtist: episode.effectiveRabbi,
            MPNowPlayingInfoPropertyElapsedPlaybackTime: seconds.isFinite ? max(0, seconds) : 0,
            MPNowPlayingInfoPropertyPlaybackRate: player?.rate ?? 0
        ]
        if let duration = player?.currentItem?.duration.seconds,
           duration.isFinite && duration > 0 {
            info[MPMediaItemPropertyPlaybackDuration] = duration
        }
        MPNowPlayingInfoCenter.default().nowPlayingInfo = info
    }
    private func removeObservers() {
        if let obs = endObserver { NotificationCenter.default.removeObserver(obs); endObserver=nil }
        if let token = positionObserver, let player = player {
            player.removeTimeObserver(token)
        }
        positionObserver=nil
    }
}
