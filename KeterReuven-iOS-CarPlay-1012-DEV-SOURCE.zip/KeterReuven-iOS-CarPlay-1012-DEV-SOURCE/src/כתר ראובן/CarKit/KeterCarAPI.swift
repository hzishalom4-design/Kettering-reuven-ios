import Foundation

#if canImport(FoundationNetworking)
import FoundationNetworking
#endif
/// No new backend. Same Edge endpoint and website fallback as Android Auto 1012.
struct KeterCarAPI {
    static let edgeURL = URL(string: "https://hhqnaufpiqncnchevwjj.supabase.co/functions/v1/keter-car-api-dev")!
    static let websiteFeed = URL(string: "https://www.keter-reuven.co.il/api/gateway?krRoute=radio-feed")!

    private func fetch<T: Decodable>(_ url: URL, as type: T.Type) async throws -> T {
        var request = URLRequest(url: url)
        request.timeoutInterval = 9
        request.cachePolicy = .reloadIgnoringLocalCacheData
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        let (body, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse, http.statusCode == 200,
              body.count < 5_000_000 else { throw KeterCarError.unavailable }
        return try JSONDecoder().decode(type, from: body)
    }

    private func edgeRecordings() async throws -> [KeterEpisode] {
        var all: [KeterEpisode] = []
        var cursor = "0"
        var cursors = Set<String>()
        var ids = Set<String>()
        for _ in 0..<30 {
            guard cursors.insert(cursor).inserted else { break }
            var components = URLComponents(url: Self.edgeURL, resolvingAgainstBaseURL: false)!
            components.queryItems = [.init(name: "route", value: "browse"),
                                     .init(name: "cursor", value: cursor)]
            guard let url = components.url else { throw KeterCarError.invalidResponse }
            let page = try await fetch(url, as: KeterBrowseResponse.self)
            guard page.ok else { throw KeterCarError.unavailable }
            for episode in page.items where episode.safeAudioURL != nil {
                if ids.insert(episode.id).inserted { all.append(episode) }
                if all.count >= 1_500 { return all }
            }
            guard let next = page.nextCursor, next != cursor,
                  next.range(of: "^[0-9]{1,8}$", options: .regularExpression) != nil else { break }
            cursor = next
        }
        return all
    }

    func recordings() async throws -> [KeterEpisode] {
        var all: [KeterEpisode] = []
        do { all = try await edgeRecordings() } catch { /* try the site's public backup */ }
        if all.isEmpty {
            let site = try await fetch(Self.websiteFeed, as: KeterSiteFeed.self)
            guard site.ok else { throw KeterCarError.unavailable }
            var ids = Set<String>()
            all = site.episodes.filter { $0.safeAudioURL != nil && ids.insert($0.id).inserted }
        }
        return all.sorted {
            let a = $0.publishedDate ?? .distantPast
            let b = $1.publishedDate ?? .distantPast
            return a == b ? $0.id < $1.id : a > b
        }
    }
}
