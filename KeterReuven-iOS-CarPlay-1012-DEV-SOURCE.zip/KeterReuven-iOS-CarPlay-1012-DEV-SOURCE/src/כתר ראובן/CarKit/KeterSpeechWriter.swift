import Foundation
import AVFoundation

/// Converts genuine Hebrew speech into an audio file, so the shared media player and
/// the vehicle's steering-wheel controls operate on the briefing like other audio.
@MainActor
final class KeterSpeechWriter {
    static let shared = KeterSpeechWriter()
    private let synthesizer = AVSpeechSynthesizer()
    private var rendering = false
    enum RenderError: Error { case noHebrewVoice, noAudio, interrupted }
    private init() {}

    func makeAudio(_ text: String) async throws -> URL {
        guard !rendering else { throw RenderError.interrupted }
        guard let voice = AVSpeechSynthesisVoice(language: "he-IL") else { throw RenderError.noHebrewVoice }
        rendering = true
        defer { rendering = false }
        let directory = FileManager.default.temporaryDirectory
        let old = (try? FileManager.default.contentsOfDirectory(at: directory, includingPropertiesForKeys: [.contentModificationDateKey])) ?? []
        for file in old where file.lastPathComponent.hasPrefix("kr-prayers-") && file.pathExtension == "caf" {
            if let age = try? file.resourceValues(forKeys: [.contentModificationDateKey]).contentModificationDate,
               Date().timeIntervalSince(age) > 86_400 { try? FileManager.default.removeItem(at: file) }
        }
        let url = FileManager.default.temporaryDirectory.appendingPathComponent("kr-prayers-\(UUID().uuidString).caf")
        let utterance = AVSpeechUtterance(string: text)
        utterance.voice = voice
        utterance.rate = AVSpeechUtteranceDefaultSpeechRate
        return try await withCheckedThrowingContinuation { continuation in
            let mutex = NSLock()
            var output: AVAudioFile?
            var finished = false
            DispatchQueue.main.asyncAfter(deadline: .now() + 35) {
                mutex.lock()
                guard !finished else { mutex.unlock(); return }
                finished = true
                output = nil
                mutex.unlock()
                self.synthesizer.stopSpeaking(at: .immediate)
                continuation.resume(throwing: RenderError.interrupted)
            }
            self.synthesizer.write(utterance) { buffer in
                mutex.lock()
                defer { mutex.unlock() }
                guard !finished else { return }
                guard let pcm = buffer as? AVAudioPCMBuffer else { return }
                if pcm.frameLength == 0 {
                    finished = true
                    output = nil
                    if FileManager.default.fileExists(atPath: url.path) {
                        continuation.resume(returning: url)
                    } else { continuation.resume(throwing: RenderError.noAudio) }
                    return
                }
                do {
                    if output == nil { output = try AVAudioFile(forWriting: url, settings: pcm.format.settings) }
                    try output?.write(from: pcm)
                } catch {
                    finished = true
                    output = nil
                    continuation.resume(throwing: error)
                }
            }
        }
    }
}
