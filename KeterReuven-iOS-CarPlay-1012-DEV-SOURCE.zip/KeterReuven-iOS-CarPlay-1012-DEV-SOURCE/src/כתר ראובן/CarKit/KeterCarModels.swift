import Foundation

/// Published recordings from the existing Keter Car API or the site's public feed.
/// Site-feed field names differ from the Edge API; decode both without a second database.
struct KeterEpisode: Decodable, Hashable, Identifiable {
    let id: String
    let title: String
    let description: String?
    let streamUrl: URL
    let imageUrl: URL?
    let publishedAt: String?
    let category: String?
    let kind: String?
    let rabbi: String?

    enum CodingKeys: String, CodingKey {
        case id, title, description, streamUrl, audio, imageUrl, image
        case publishedAt, pubDate, category, kind, rabbi
    }

    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        let audio = try c.decodeIfPresent(String.self, forKey: .streamUrl)
            ?? c.decodeIfPresent(String.self, forKey: .audio)
            ?? ""
        guard let url = URL(string: audio), url.scheme?.lowercased() == "https",
              url.host != nil, url.user == nil, url.password == nil else {
            throw KeterCarError.invalidResponse
        }
        streamUrl = url
        let rawId = (try c.decodeIfPresent(String.self, forKey: .id)) ?? audio
        id = rawId.isEmpty ? audio : rawId
        title = (try c.decodeIfPresent(String.self, forKey: .title)) ?? "שיעור תורה"
        description = try c.decodeIfPresent(String.self, forKey: .description)
        let art = try c.decodeIfPresent(String.self, forKey: .imageUrl)
            ?? c.decodeIfPresent(String.self, forKey: .image)
        if let art, let u = URL(string: art), u.scheme?.lowercased() == "https",
           u.host != nil, u.user == nil, u.password == nil { imageUrl = u }
        else { imageUrl = nil }
        publishedAt = try c.decodeIfPresent(String.self, forKey: .publishedAt)
            ?? c.decodeIfPresent(String.self, forKey: .pubDate)
        category = try c.decodeIfPresent(String.self, forKey: .category)
        kind = try c.decodeIfPresent(String.self, forKey: .kind)
        rabbi = try c.decodeIfPresent(String.self, forKey: .rabbi)
    }

    var safeAudioURL: URL? {
        guard streamUrl.scheme?.lowercased() == "https", streamUrl.host != nil,
              streamUrl.user == nil, streamUrl.password == nil else { return nil }
        return streamUrl
    }

    var publishedDate: Date? {
        guard let value = publishedAt, !value.isEmpty else { return nil }
        let iso = ISO8601DateFormatter()
        iso.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        if let date = iso.date(from: value) { return date }
        iso.formatOptions = [.withInternetDateTime]
        if let date = iso.date(from: value) { return date }
        let rfc = DateFormatter()
        rfc.locale = Locale(identifier: "en_US_POSIX")
        rfc.dateFormat = "EEE, dd MMM yyyy HH:mm:ss Z"
        if let date = rfc.date(from: value) { return date }
        let local = DateFormatter()
        local.locale = Locale(identifier: "en_US_POSIX")
        local.timeZone = TimeZone(identifier: "Asia/Jerusalem")
        local.dateFormat = "yyyy-MM-dd"
        return local.date(from: value)
    }

    var dateLabel: String {
        guard let date = publishedDate else { return "" }
        let f = DateFormatter()
        f.locale = Locale(identifier: "he_IL")
        f.timeZone = TimeZone(identifier: "Asia/Jerusalem")
        f.dateFormat = "dd.MM.yyyy"
        return f.string(from: date)
    }

    var effectiveRabbi: String {
        let aliases: [(String, [String])] = [
            ("הרב אברהם דימרי", ["אברהם דימרי", "אברהם דמרי"]),
            ("הרב אפרים דגן", ["אפרים דגן"]),
            ("הרב עובדיה דגן", ["עובדיה דגן"]),
            ("הרב אברהם שלום", ["אברהם שלום"]),
            ("הרב משה יוסף", ["משה יוסף"]),
            ("הרב אלמוג לוי", ["אלמוג לוי"]),
            ("הרב שקד בוהדנה", ["שקד בוהדנה"]),
            ("הרב משה בן דוד", ["משה בן דוד"]),
            ("הרב גיא אלקנה לוטינגר", ["גיא אלקנה לוטינגר"])
        ]
        let explicit = rabbi?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        let source = (explicit.isEmpty ? title : explicit).folding(options: [.diacriticInsensitive, .caseInsensitive], locale: Locale(identifier: "he_IL"))
        for (canonical, variants) in aliases where variants.contains(where: { source.contains($0) }) {
            return canonical
        }
        if !explicit.isEmpty && explicit.count < 120 { return explicit }
        return "שיעורים נוספים"
    }
}

struct KeterBrowseResponse: Decodable {
    let ok: Bool
    let items: [KeterEpisode]
    let nextCursor: String?
}

struct KeterSiteFeed: Decodable {
    let ok: Bool
    let episodes: [KeterEpisode]
}

enum KeterCarError: Error {
    case invalidResponse
    case unavailable
    case untrustedSource
}
