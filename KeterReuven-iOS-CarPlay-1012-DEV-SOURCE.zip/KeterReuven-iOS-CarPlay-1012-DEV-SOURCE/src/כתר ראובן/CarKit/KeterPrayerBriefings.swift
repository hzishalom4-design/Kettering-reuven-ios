import Foundation
#if canImport(FoundationNetworking)
import FoundationNetworking
#endif

/// Accurate spoken briefings. Never generate a prayer time from a missing or stale schedule.
struct KeterPrayerRow: Decodable {
    let name: String
    let time: String
    let note: String?
    let oneTime: Bool?
}

private struct KeterPrayerSection: Decodable { let items: [KeterPrayerRow]? }
private struct KeterHolidayGroup: Decodable { let date: String; let items: [KeterPrayerRow]? }
private struct KeterHolidays: Decodable { let enabled: Bool?; let groups: [KeterHolidayGroup]? }
private struct KeterAutoZmanim: Decodable { let date: String? }
private struct KeterSchedule: Decodable {
    let source: String?
    let weekday: [KeterPrayerRow]?
    let shabbat: KeterPrayerSection?
    let holidays: KeterHolidays?
    let auto: KeterAutoZmanim?
    enum CodingKeys: String, CodingKey {
        case source = "_source", weekday, shabbat, holidays, auto = "_autoZmanim"
    }
}

struct KeterPrayerSnapshot {
    let createdAt: Date
    let rows: [KeterPrayerRow]
    let warning: String?
    var next: KeterPrayerRow? {
        let minutes = KeterPrayerService.minuteOfDay(createdAt)
        return rows.first { KeterPrayerService.minutes($0.time).map { $0 >= minutes } ?? false }
    }
    var nextLabel: String {
        guard let next else { return rows.isEmpty ? "אין זמני תפילות מאומתים" : "התפילות היום הסתיימו" }
        return "\(next.name) · \(next.time)"
    }
    var nextDetail: String {
        guard let next, let time = KeterPrayerService.minutes(next.time) else { return warning ?? "אין עוד תפילות היום" }
        let delta = max(0, time - KeterPrayerService.minuteOfDay(createdAt))
        return warning ?? (delta == 0 ? "עכשיו" : delta < 60 ? "בעוד \(delta) דקות" : "בעוד \(delta / 60) שעות" + (delta % 60 > 0 ? " ו־\(delta % 60) דקות" : ""))
    }
    func narration(all: Bool) -> String {
        let date = DateFormatter()
        date.locale = Locale(identifier: "he_IL")
        date.timeZone = TimeZone(identifier: "Asia/Jerusalem")
        date.dateFormat = "dd.MM.yyyy"
        let clock = KeterPrayerService.clock(KeterPrayerService.minuteOfDay(createdAt))
        let introduction = "כתר ראובן, רמלה. עדכון זמני תפילות ליום \(date.string(from: createdAt)), נכון לשעה \(KeterPrayerService.spoken(clock)). " + (warning ?? "")
        if rows.isEmpty { return introduction + "אין כרגע לוח תפילות מאומת. יש לבדוק באתר כתר ראובן." }
        if all { return introduction + rows.map { "\($0.name), \(KeterPrayerService.spoken($0.time))." }.joined(separator: " ") }
        guard let next else { return introduction + "תפילות היום הסתיימו לפי הלוח." }
        return introduction + "התפילה הקרובה, \(next.name), \(KeterPrayerService.spoken(next.time)), \(nextDetail)."
    }
}

actor KeterPrayerService {
    static let shared = KeterPrayerService()
    private let endpoint = URL(string: "https://www.keter-reuven.co.il/api/schedule")!
    private var cached: KeterSchedule?
    private var fetchedAt: Date?
    private var cachedDay: String?

    static let zone = TimeZone(identifier: "Asia/Jerusalem")!
    static func calendar(_ identifier: Calendar.Identifier = .gregorian) -> Calendar {
        var result = Calendar(identifier: identifier)
        result.timeZone = zone
        return result
    }
    static func minutes(_ value: String) -> Int? {
        let p = value.trimmingCharacters(in: .whitespaces).split(separator: ":")
        guard p.count == 2, p[1].count == 2, let h = Int(p[0]), let m = Int(p[1]),
              (0..<24).contains(h), (0..<60).contains(m) else { return nil }
        return h * 60 + m
    }
    static func clock(_ minutes: Int) -> String { String(format: "%02d:%02d", minutes / 60, minutes % 60) }
    static func spoken(_ value: String) -> String {
        guard let m = minutes(value) else { return "שעה לא זמינה" }
        return m % 60 == 0 ? "בשעה \(m / 60) בדיוק" : "בשעה \(m / 60) ו־\(m % 60) דקות"
    }
    static func minuteOfDay(_ date: Date) -> Int {
        let c = calendar().dateComponents([.hour, .minute], from: date)
        return (c.hour ?? 0) * 60 + (c.minute ?? 0)
    }
    private static func dayKey(_ date: Date) -> String {
        let f = DateFormatter()
        f.locale = Locale(identifier: "en_US_POSIX")
        f.timeZone = zone
        f.dateFormat = "yyyy-MM-dd"
        return f.string(from: date)
    }
    private static func cleaned(_ string: String) -> String {
        string.replacingOccurrences(of: "<[^>]*>", with: " ", options: .regularExpression)
              .replacingOccurrences(of: "[\\p{C}]", with: " ", options: .regularExpression)
              .trimmingCharacters(in: .whitespacesAndNewlines)
    }
    private static func validPrayer(_ name: String) -> Bool {
        let names = ["שחרית", "מנחה", "ערבית", "מוסף", "סליחות", "נעילה", "כל נדרי", "ותיקין", "וותיקין", "נץ החמה", "קבלת שבת", "תפילת"]
        let excluded = ["שיעור", "תהילים", "דף יומי", "לימוד", "דרשה", "אבות ובנים", "הדלקת נרות"]
        return names.contains(where: name.contains) && !excluded.contains(where: name.contains)
    }
    private static func fridayRow(_ name: String) -> Bool {
        name.contains("ערב שבת") || name.contains("ליל שבת") || name.contains("קבלת שבת")
    }
    private static func hebrewNumeral(_ value: Int) -> String {
        let table: [(Int, String)] = [(400,"ת"),(300,"ש"),(200,"ר"),(100,"ק"),(90,"צ"),(80,"פ"),(70,"ע"),(60,"ס"),(50,"נ"),(40,"מ"),(30,"ל"),(20,"כ"),(10,"י"),(9,"ט"),(8,"ח"),(7,"ז"),(6,"ו"),(5,"ה"),(4,"ד"),(3,"ג"),(2,"ב"),(1,"א")]
        var rest = value
        var text = ""
        for (num, letter) in table {
            while rest >= num {
                if rest == 15 { text += "טו"; rest = 0; break }
                if rest == 16 { text += "טז"; rest = 0; break }
                text += letter; rest -= num
            }
        }
        return text
    }
    private static func matchesSpecial(_ raw: String, today: Date) -> Bool {
        let s = cleaned(raw).replacingOccurrences(of: "חשון", with: "חשוון")
          .replacingOccurrences(of: "סיון", with: "סיוון")
          .replacingOccurrences(of: "אדר ב", with: "אדר")
          .replacingOccurrences(of: "׳", with: "").replacingOccurrences(of: "״", with: "")
        let f = DateFormatter()
        f.timeZone = zone
        f.locale = Locale(identifier: "en_US_POSIX")
        for pattern in ["yyyy-MM-dd", "d.M.yyyy", "dd.MM.yyyy"] {
            f.dateFormat = pattern
            if s == f.string(from: today) { return true }
        }
        let h = calendar(.hebrew).dateComponents([.year,.month,.day], from: today)
        guard let month = h.month, let day = h.day, let year = h.year else { return false }
        let months = ["תשרי", "חשוון", "כסלו", "טבת", "שבט", "אדר א", "אדר", "ניסן", "אייר", "סיוון", "תמוז", "אב", "אלול"]
        guard (1...13).contains(month) else { return false }
        let label = months[month-1]
        let d = hebrewNumeral(day)
        let y = hebrewNumeral(year - 5000)
        return ["\(d) ב\(label)", "\(d) \(label)", "\(d) ב\(label) ה\(y)", "\(d) ב\(label) \(y)"].contains(s)
    }
    private static func isSpecialDay(_ date: Date) -> Bool {
        let h = calendar(.hebrew).dateComponents([.month,.day], from: date)
        let m = (h.month ?? 0) - 1, d = h.day ?? 0
        return d == 1 || d == 30 || (m == 0 && (d <= 4 || d == 9 || d == 10 || (14...23).contains(d))) ||
            (m == 2 && d >= 25) || (m == 3 && (d <= 3 || d == 10)) ||
            (m == 6 && (13...15).contains(d)) || (m == 7 && (14...22).contains(d)) ||
            (m == 9 && (5...7).contains(d)) || (m == 10 && [17, 18].contains(d)) ||
            (m == 11 && [9, 10].contains(d))
    }
    private static func selected(_ schedule: KeterSchedule, at date: Date) -> (rows: [KeterPrayerRow], warning: String?) {
        let c = calendar()
        let weekday = c.component(.weekday, from: date) // Sunday 1, Friday 6, Saturday 7
        let special = (schedule.holidays?.enabled ?? false) ? (schedule.holidays?.groups ?? []).filter { matchesSpecial($0.date, today: date) } : []
        if special.count > 1 || (isSpecialDay(date) && special.isEmpty) {
            return ([], "לא נמצא לוח מיוחד מאומת להיום. יש לבדוק באתר כתר ראובן. ")
        }
        let freshAuto = schedule.auto?.date == dayKey(date)
        var selected: [KeterPrayerRow]
        if let match = special.first { selected = match.items ?? [] }
        else if weekday == 7 { selected = (schedule.shabbat?.items ?? []).filter { !fridayRow($0.name) } }
        else if weekday == 6 {
            selected = (schedule.weekday ?? []).filter { ["שחרית", "סליחות", "ותיקין", "נץ החמה"].contains(where: $0.name.contains) }
            selected += (schedule.shabbat?.items ?? []).filter { fridayRow($0.name) && ($0.name != "מנחה 1 ערב שבת" || freshAuto || ($0.oneTime ?? false)) }
        } else { selected = schedule.weekday ?? [] }

        var rows: [KeterPrayerRow] = []
        var seen = Set<String>()
        for row in selected {
            let name = cleaned(row.name)
            guard validPrayer(name) else { continue }
            var minute = minutes(row.time)
            if special.isEmpty && weekday != 7 && !fridayRow(name) && !(row.oneTime ?? false) {
                let note = row.note ?? ""
                // Monday/Thursday temporary morning updates, but never guess the time.
                if name.hasPrefix("שחרית") && (weekday == 2 || weekday == 5) && (note.contains("שני וחמישי") || note.contains("ב׳,ה׳") || note.contains("ב-ה")) {
                    if let time = note.range(of: "[0-9]{1,2}:[0-9]{2}", options: .regularExpression) {
                        minute = minutes(String(note[time]))
                    }
                }
                if name == "ערבית 3" && weekday == 4 && note.contains("20:45") { minute = minutes("20:45") }
                if !freshAuto && ["מנחה 1", "מנחה מוקדמת", "מנחה גדולה", "ערבית מוקדמת"].contains(name) { continue }
            }
            guard let minute else { continue }
            let key = "\(name)|\(clock(minute))"
            if seen.insert(key).inserted {
                // Use validated clock, not the original free-form value.
                rows.append(KeterPrayerRow(name: name, time: clock(minute), note: row.note, oneTime: row.oneTime))
            }
        }
        rows.sort { (minutes($0.time) ?? 0) < (minutes($1.time) ?? 0) }
        let warning = !freshAuto && special.isEmpty && weekday != 7 ? "שעות אוטומטיות שלא אומתו אינן מוצגות. " : nil
        return (rows, warning)
    }

    func snapshot() async -> KeterPrayerSnapshot {
        let now = Date(), day = Self.dayKey(now)
        var stale = false
        if cached == nil || cachedDay != day || now.timeIntervalSince(fetchedAt ?? .distantPast) > 30 {
            do {
                var req = URLRequest(url: endpoint)
                req.timeoutInterval = 7
                req.cachePolicy = .reloadIgnoringLocalCacheData
                let (data, response) = try await URLSession.shared.data(for: req)
                guard let response = response as? HTTPURLResponse, response.statusCode == 200,
                      data.count < 700_000 else { throw KeterCarError.unavailable }
                let schedule = try JSONDecoder().decode(KeterSchedule.self, from: data)
                guard schedule.source == "supabase", schedule.weekday != nil else { throw KeterCarError.untrustedSource }
                cached = schedule; cachedDay = day; fetchedAt = Date()
            } catch {
                stale = true
                if cachedDay != day || now.timeIntervalSince(fetchedAt ?? .distantPast) > 120 {
                    cached = nil
                }
            }
        }
        guard let cached else {
            return KeterPrayerSnapshot(createdAt: now, rows: [], warning: "זמני התפילות אינם זמינים כרגע. ")
        }
        let selected = Self.selected(cached, at: now)
        let warning = (stale ? "הלוח נשמר לפני פחות משתי דקות. " : "") + (selected.warning ?? "")
        return KeterPrayerSnapshot(createdAt: now, rows: selected.rows,
                                   warning: warning.isEmpty ? nil : warning)
    }
}

