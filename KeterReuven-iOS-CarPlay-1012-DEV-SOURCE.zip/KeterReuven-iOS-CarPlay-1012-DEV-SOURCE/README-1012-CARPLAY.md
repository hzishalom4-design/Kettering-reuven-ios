# 👑 כתר ראובן — Apple CarPlay 1012 (DEV / HOLD)

**פיתוח מקביל — אין תלות באישור Google Play.** נלקחה חבילת המקור של Build 5 לאפליקציית iOS הקיימת (`il.co.keter-reuven.app`) ונוספו התאמות ל-1012 שבדקתם ב-Android Auto. לא בוצעו שינויים בענן/באתר/באנדרואיד ולא נבנתה אפליקציה חדשה ב-App Store.

## מה יש בקוד

1. מסך שיעורים מוקלטים עם רדיו ישיר, המשך האזנה, כל השיעורים לפי תאריך, תיקיות לפי רבנים ורשימות מדורגות. לחיצה על השיעור מפעילה AVPlayer ואת CarPlay Now Playing.
2. חידוש/השהיה, קודם/הבא, דילוג 15 שניות אחורה ו-30 קדימה דרך MPRemoteCommandCenter; כפתורי ההגה תלויים ביצרן הרכב.
3. מסך תפילות: פריט להקראת התפילה הקרובה, פריט להקראת כל היום, ופריטי שמע לכל תפילה. הלוח נשלף מהאתר ומאומת; הקראה בקול `he-IL` נוצרה לקובץ שמע אמיתי ונשלחת דרך הנגן המשותף.
4. תמונות שיעורים ורבנים, תור רצוף, נקודת האזנה מקומית, נסיונות fallback מול האתר.

## דברים שעדיין לא הוכחו

- אין כאן Xcode או macOS: **בוצעו בדיקות תחביר Swift, בדיקת typecheck של מודלים/תפילות, אימות plist ובדיקות unit קטנות, אך לא בוצעה קומפילציית iOS מלאה.**
- אין אישור/Entitlement של Apple למסלול CarPlay Audio שמופיע אצלנו; לא הוספנו אותו באופן פיקטיבי.
- אין IPA/TestFlight, אין בדיקה ברכב אמיתי או ב-CarPlay Simulator, ואין אישור App Review.
- Apple עשויה להגביל את תצוגת פריטי זמני התפילות; הם תוכננו כהשמעת שמע אמיתית ולא כטקסט תצוגה כללי.
- חיפוש קולי מפורש של רב דרך Siri עדיין לא נבדק/לא נכלל בפיתוח הזה; גם הורדות לשמיעה לא מקוונת לא נוספו.

## תהליך בנייה (ללא יצירת פרויקט חדש)

יש לשלב את קובצי `src/` בפרויקט ה-iOS הקיים ב-GitHub או לעבוד מתוך תיקיית הפרויקט המצורפת, ולהריץ GitHub Actions על macOS או ב-Mac מקומי.

### Mac עם Xcode
```bash
bash scripts/build-ios-simulator-macos.sh
```

### GitHub Actions
במקום ליצור ריפו חדש, עדכן את הריפו הקיים של iOS עם הקוד אחרי סקירת diff, והריץ את workflow `ios-simulator-build.yml`. קובץ הארטיפקט הוא **לסימולטור בלבד**, לא להתקנה באייפון.

### התקנה ברכב אחרי אישור הרשאת Apple
1. בקש מאפל CarPlay Audio עבור App ID הקיים: https://developer.apple.com/carplay/
2. בדוק שב-Apple Developer הפעילות מאושרת ושפרופיל החתימה תואם.
3. רק לאחר אישור בפועל, בסביבת macOS:
```bash
CARPLAY_AUDIO_APPROVED=YES bash scripts/enable-carplay-after-approval-macos.sh
export APPLE_TEAM_ID=YOUR_TEAM_ID
bash scripts/build-signed-archive-macos.sh
```
4. לבנות IPA/TestFlight, לבדוק iPhone ו-CarPlay ברכב, ואז לשלוח ל-App Store Review.

**אין להעלות לאינטרנט מפתחות חתימה או provisioning profiles פרטיים.**

ראו `QA-CARPLAY-1012-DEV.md` לרשימת בדיקות.
