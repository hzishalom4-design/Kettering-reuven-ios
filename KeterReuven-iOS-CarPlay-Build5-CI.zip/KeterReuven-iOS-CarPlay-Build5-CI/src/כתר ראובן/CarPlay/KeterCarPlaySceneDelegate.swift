import UIKit
import CarPlay

/// CarPlay scene for the SAME app bundle as the iPhone application.
/// Requires a valid Apple-issued CarPlay Audio entitlement and signing profile.
final class KeterCarPlaySceneDelegate: UIResponder, CPTemplateApplicationSceneDelegate {
    private weak var controller: CPInterfaceController?
    private let api = KeterCarAPI()
    private var current = [KeterEpisode]()

    func templateApplicationScene(_ templateApplicationScene: CPTemplateApplicationScene,
                                  didConnect interfaceController: CPInterfaceController) {
        controller = interfaceController
        let loading = CPListItem(text: "טוען שיעורים…", detailText: "כתר ראובן")
        interfaceController.setRootTemplate(
            CPListTemplate(title: "כתר ראובן", sections: [CPListSection(items: [loading])]),
            animated: false, completion: nil)
        Task { @MainActor in await refreshCatalog() }
    }

    func templateApplicationScene(_ templateApplicationScene: CPTemplateApplicationScene,
                                  didDisconnect interfaceController: CPInterfaceController) {
        // Keep the phone's playback alive after disconnection.
        controller = nil
    }

    @MainActor private func refreshCatalog() async {
        do {
            let episodes = try await api.recordings()
            guard controller != nil else { return } // Ignore a late response after disconnect.
            current = episodes
            displayPage(0)
        } catch {
            guard controller != nil else { return }
            let retry = CPListItem(text: "נסה לטעון שוב", detailText: "השיעורים אינם זמינים כעת")
            retry.handler = { [weak self] _, completion in
                completion()
                Task { @MainActor in await self?.refreshCatalog() }
            }
            controller?.setRootTemplate(CPListTemplate(title: "כתר ראובן",
                sections: [CPListSection(items: [retry])]), animated: true, completion: nil)
        }
    }

    /// CarPlay truncates items above `maximumItemCount` and limits template-stack depth.
    /// Replace only the root with previous/next buttons, avoiding an 18-level stack.
    @MainActor private func displayPage(_ page: Int) {
        guard let controller else { return }
        let limit = max(1, CPListTemplate.maximumItemCount)
        let pageSize = max(1, min(10, limit - 3)) // Radio row plus previous/next controls.
        let start = page * pageSize
        guard start >= 0, start < current.count || (page == 0 && current.isEmpty) else { return }
        let segment = Array(current.dropFirst(start).prefix(pageSize))
        var rows: [CPListItem] = []
        if page == 0 && !current.isEmpty {
            let radio = CPListItem(text: "רדיו כתר ראובן — השמעה ברצף",
                                   detailText: "שיעורים מוקלטים אחד אחרי השני")
            radio.handler = { [weak self] _, completion in
                Task { @MainActor in
                    defer { completion() }
                    guard let self, self.controller != nil else { return }
                    do {
                        try KeterAudioPlayer.shared.playRadio(self.current)
                        self.controller?.pushTemplate(CPNowPlayingTemplate.shared,
                                                      animated: true, completion: nil)
                    } catch {
                        // Do not claim playback has started if audio setup failed.
                    }
                }
            }
            rows.append(radio)
        }
        rows.append(contentsOf: segment.map { episode in
            let row = CPListItem(text: episode.title, detailText: "שיעור מוקלט")
            row.handler = { [weak self] _, completion in
                Task { @MainActor in
                    defer { completion() }
                    guard let self, self.controller != nil else { return }
                    do {
                        try KeterAudioPlayer.shared.play(episode, from: self.current)
                        self.controller?.pushTemplate(CPNowPlayingTemplate.shared,
                                                      animated: true, completion: nil)
                    } catch {
                        // Playback is not marked successful on stream or session failure.
                    }
                }
            }
            return row
        })
        if page > 0 {
            let previous = CPListItem(text: "שיעורים קודמים", detailText: "חזרה לעמוד הקודם")
            previous.handler = { [weak self] _, completion in
                completion()
                Task { @MainActor in self?.displayPage(page - 1) }
            }
            rows.append(previous)
        }
        if start + segment.count < current.count {
            let more = CPListItem(text: "עוד שיעורים",
                                  detailText: "הצג עוד מתוך \(current.count) הקלטות")
            more.handler = { [weak self] _, completion in
                completion()
                Task { @MainActor in self?.displayPage(page + 1) }
            }
            rows.append(more)
        }
        if rows.isEmpty { rows = [CPListItem(text: "אין הקלטות זמינות", detailText: nil)] }
        let list = CPListTemplate(title: "שיעורים מוקלטים",
                                  sections: [CPListSection(items: rows)])
        controller.setRootTemplate(list, animated: true, completion: nil)
    }
}
