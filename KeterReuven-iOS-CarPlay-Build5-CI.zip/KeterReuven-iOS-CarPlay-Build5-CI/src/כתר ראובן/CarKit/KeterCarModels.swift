import Foundation

/// API v1 is read-only. Never infer a real minyan from missing data or a stale response.
struct KeterEpisode: Codable, Hashable, Identifiable {
    let id: String
    let title: String
    let description: String?
    let streamUrl: URL
    let imageUrl: URL?
    let publishedAt: String?
    let category: String?
    let kind: String?

    var safeAudioURL: URL? {
        guard streamUrl.scheme?.lowercased() == "https", streamUrl.host != nil,
              streamUrl.user == nil, streamUrl.password == nil else { return nil }
        return streamUrl
    }
}

struct KeterBrowseResponse: Decodable {
    let ok: Bool
    let items: [KeterEpisode]
    let nextCursor: String?
}

struct KeterPrayer: Decodable {
    let name: String
    let time: String
    let note: String?
    let minutesUntil: Int
}

struct KeterNextPrayerData: Decodable {
    let date: String?
    let available: Bool
    let prayer: KeterPrayer?
    let reason: String?
    let source: String?
    let checkedAt: String?
}

struct KeterPrayerResponse: Decodable {
    let ok: Bool
    let data: KeterNextPrayerData
}

enum KeterCarError: Error {
    case invalidResponse
    case unavailable
    case untrustedSource
}
