import Foundation

/// Shared by phone player, CarPlay templates and the WidgetKit extension.
/// Add these files to both application and widget targets in Xcode.
struct KeterCarAPI {
    static let baseURL = URL(string: "https://hhqnaufpiqncnchevwjj.supabase.co/functions/v1/keter-car-api-dev")!

    private func fetch<T: Decodable>(_ route: String, cursor: String? = nil, as type: T.Type) async throws -> T {
        var parts = URLComponents(url: Self.baseURL, resolvingAgainstBaseURL: false)!
        parts.queryItems = [URLQueryItem(name: "route", value: route)]
        if let cursor { parts.queryItems?.append(URLQueryItem(name: "cursor", value: cursor)) }
        guard let url = parts.url else { throw KeterCarError.invalidResponse }
        var req = URLRequest(url: url)
        req.timeoutInterval = 8
        req.cachePolicy = .reloadIgnoringLocalCacheData
        req.setValue("application/json", forHTTPHeaderField: "Accept")
        let (body, response) = try await URLSession.shared.data(for: req)
        guard let status = response as? HTTPURLResponse,
              status.statusCode == 200,
              body.count <= 450_000 else { throw KeterCarError.unavailable }
        return try JSONDecoder().decode(type, from: body)
    }

    func recordings() async throws -> [KeterEpisode] {
        var all: [KeterEpisode] = []
        var cursor: String? = "0"
        var seen = Set<String>()
        for _ in 0..<10 {
            guard let current = cursor else { break }
            let response = try await fetch("browse", cursor: current, as: KeterBrowseResponse.self)
            guard response.ok else { throw KeterCarError.unavailable }
            for episode in response.items where episode.safeAudioURL != nil {
                if seen.insert(episode.id).inserted { all.append(episode) }
                if all.count >= 500 { return all }
            }
            guard let next = response.nextCursor, next != current,
                  next.range(of: "^[0-9]{1,2}$", options: .regularExpression) != nil else { break }
            cursor = next
        }
        return all
    }

    func verifiedNextPrayer() async throws -> KeterNextPrayerData {
        let response = try await fetch("next-prayer", as: KeterPrayerResponse.self)
        guard response.ok, response.data.source == "supabase" else {
            throw KeterCarError.untrustedSource
        }
        guard let date = response.data.checkedAt,
              let stamp = ISO8601DateFormatter().date(from: date),
              abs(stamp.timeIntervalSinceNow) < 120 else { throw KeterCarError.untrustedSource }
        return response.data
    }
}
