#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")"
if ! command -v git >/dev/null 2>&1; then
  echo 'git not found. Install it before continuing.' >&2; exit 2
fi
if ! command -v gh >/dev/null 2>&1; then
  echo 'GitHub CLI (gh) not found. On Cloud Shell run: sudo apt-get update && sudo apt-get install -y gh' >&2
  exit 2
fi
if ! gh auth status >/dev/null 2>&1; then
  echo 'Authenticate with your own GitHub account in the browser. Never paste tokens here.'
  gh auth login --web --git-protocol https
fi
if [ ! -d .git ]; then
  git init -b main
  git config user.email "$(gh api user --jq '.login')@users.noreply.github.com"
  git config user.name "$(gh api user --jq '.login')"
  git add .
  git commit -m 'Keter Reuven existing iOS app CarPlay simulator build'
fi
if ! git remote get-url origin >/dev/null 2>&1; then
  repo='KeterReuven-iOS-CarPlay-Build'
  echo "Creating PRIVATE repo: $repo"
  gh repo create "$repo" --private --source=. --remote=origin --push
else
  git push -u origin main
fi
repo_url="$(git remote get-url origin)"
echo "Repo: $repo_url"
echo 'A macOS GitHub Actions simulator build starts on push to main.'
echo 'You can track it on GitHub -> Actions. If necessary, run manually:'
echo 'gh workflow run ios-simulator-build.yml'
