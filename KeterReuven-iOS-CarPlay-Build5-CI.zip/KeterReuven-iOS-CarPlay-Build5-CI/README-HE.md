# 👑 כתר ראובן — בניית iOS + Apple CarPlay (מקור Build 5)

זוהי **האפליקציה הקיימת**, עם אותם Bundle ID, מסכי טלפון, סמל, מצפן והתראות. נוספו נתיבי Apple CarPlay Audio בקוד המקור. לא נבנתה אפליקציה חדשה מאפס.

## סטטוס נכון לעכשיו
- הוכן פרויקט Xcode מקורי ומסלול בנייה בענן באמצעות GitHub Actions על שרת macOS.
- אומתו מקומית קובצי plist ותחביר Swift (זו **לא** קומפילציית Xcode).
- **לא נוצר IPA ולא נוצר קובץ שניתן להתקנה באייפון**. הפעלת התהליך במחשבי GitHub יכולה לייצר קובץ `.app` *לסימולטור בלבד*.
- הרשאת `com.apple.developer.carplay-audio` **אינה נמצאת** כרגע בקובץ ה־entitlements ואסור להוסיף אותה כיכולת מוכרת לפני אישור Apple לפרופיל של האפליקציה.
- כתובת שרת ה־Car API היא כתובת פיתוח. אין אישור שהשירות נגיש או שהאתר החי משולב מול הנגן.

## הפעלת בניית הסימולטור מ־Google Cloud Shell
1. העלה את הקובץ `KeterReuven-iOS-CarPlay-Build5-CI.zip` ל־Cloud Shell.
2. הפעל:

```bash
cd ~
unzip -oq KeterReuven-iOS-CarPlay-Build5-CI.zip
cd KeterReuven-iOS-CarPlay-Build5-CI
bash start-ios-build-cloudshell.sh
```

3. אם `gh` חסר, הפעל `sudo apt-get update && sudo apt-get install -y gh`, ואז הפעל שוב את הסקריפט.
4. בהתחברות ל־GitHub באמצעות קוד/דפדפן, התחבר **לחשבון שלך בלבד**; אין לשלוח אלינו קודים, ססמאות או אסימונים.
5. בסיום העלאת המקור לריפו פרטי, פתח GitHub → Actions → **iOS CarPlay - Simulator Build (no signing)**. המתן לתוצאה, ושלח צילום של `Build iPhone Simulator application` אם יש כשל. אם הצליח, Artifact להורדה בסיכום ה־Run.

החשבון ב־GitHub עשוי להיות כפוף למגבלות דקות CI או עלות macOS; בדוק את תנאי חשבונך.

## אם יש Mac עם Xcode

```bash
bash scripts/build-ios-simulator-macos.sh
```

## בניית IPA אמיתי ו־CarPlay
לפני IPA חתום: חשבון Apple Developer בעל הרשאות, Team, תעודת חתימה, provisioning profile התואם ל־Bundle ID הקיים `il.co.keter-reuven.app`, והרשאת **CarPlay Audio** ש־Apple מאשרת לחשבון ול־App ID. לבקשת ההרשאה: https://developer.apple.com/carplay/

אחרי אישור אמיתי מ־Apple, ורק אז, בסביבת macOS:

```bash
CARPLAY_AUDIO_APPROVED=YES bash scripts/enable-carplay-after-approval-macos.sh
export APPLE_TEAM_ID='YOUR_ACTUAL_TEAM_ID'
bash scripts/build-signed-archive-macos.sh
```

השלב הזה יפיק `.xcarchive` אם Xcode מצליח לחתום. אחר כך יצוא IPA דרך Organizer ופרופיל ההפצה המתאים. אין כאן תעודות/מפתחות סודיים, אסור להעלות אותם ל־GitHub repository או לשלוח בצ'אט.

## בדיקות שחייבים להשלים
- אתר כתר ראובן: שילוב handoff בנגן האמיתי, ובדיקת קבצי אודיו וממשק API.
- בדיקות תפקוד: ניגון שיעור, רדיו הקלטות רציפות, דילוג, חידוש, ניתוק/חיבור רכב, שיחות טלפון והפסקות.
- בדיקת iPhone ו־CarPlay Simulator/רכב אמיתי לאחר ההרשאות.
- TestFlight בלבד אחרי QA; לא לשחרר ל־App Store לפני בדיקות.
