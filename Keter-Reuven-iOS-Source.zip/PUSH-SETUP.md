# חיבור Push Native ל־iOS — אחרי פתיחת Apple Developer

החבילה כרגע בטוחה להגשה/בדיקה בלי Push Native. הקוד כבר כולל bridge ל־APNs, אך `nativePushEnabled` מוגדר `false` ב־`Settings.swift`.

## מה נדרש

1. Apple Developer → Certificates, Identifiers & Profiles.
2. ליצור/לאשר App ID מפורש: `il.co.keter-reuven.app`.
3. להפעיל Capability בשם **Push Notifications**.
4. ליצור APNs Auth Key (`.p8`) ולשמור:
   - Team ID
   - Key ID
   - קובץ `.p8`
5. ב־Xcode להוסיף Capability **Push Notifications**.
6. ב־Background Modes להשאיר Audio; להוסיף **Remote notifications** רק כאשר צד השרת מוכן.
7. בצד השרת לשמור APNs device tokens ולשלוח דרך APNs HTTP/2. את המפתח הפרטי יש לשמור כסוד שרת בלבד — לעולם לא בתוך האפליקציה או באתר.
8. לאחר שהשרת מוכן, לשנות ב־`Settings.swift`:

```swift
let nativePushEnabled = true
```

## מה כבר מוכן בקוד

- בקשת הרשאת התראות דרך `UNUserNotificationCenter`.
- רישום ל־APNs.
- המרת device token למחרוזת והעברתו ל־WebView באירוע `push-token`.
- העברת התראה פתוחה/לחוצה ל־WebView דרך `push-notification` ו־`push-notification-click`.
- אין תלות ב־Firebase ואין קובץ GoogleService מזויף.

## Universal Links — אופציונלי

אחרי שיש Team ID ניתן ליצור באתר:

`/.well-known/apple-app-site-association`

עם appID בפורמט:

`TEAM_ID.il.co.keter-reuven.app`

ואז להוסיף ב־Xcode את Associated Domains:

`applinks:www.keter-reuven.co.il`

אין צורך בכך כדי להעלות build ראשון ל־TestFlight.
