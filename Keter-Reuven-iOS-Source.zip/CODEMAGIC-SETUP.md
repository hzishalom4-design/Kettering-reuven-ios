# כתר ראובן — העלאת Build ל-TestFlight בלי Mac

החבילה מוכנה ל-Codemagic. קובץ `codemagic.yaml` שבשורש הפרויקט יבנה IPA חתום ויעלה אותו ל-TestFlight.

## הגדרה חד-פעמית ב-Codemagic

1. חבר את חשבון GitHub ובחר את ה-repository של כתר ראובן.
2. ב-App Store Connect צור API Key עם הרשאת **App Manager** ושמור את:
   - Issuer ID
   - Key ID
   - קובץ `.p8` (אפשר להוריד אותו פעם אחת בלבד).
3. ב-Codemagic: Team settings → Integrations → Developer Portal → הוסף את המפתח בשם המדויק:
   **keter-apple**
4. ב-Code signing identities צור/הבא Apple Distribution certificate ו-App Store provisioning profile עבור:
   **il.co.keter-reuven.app**
5. פתח את האפליקציה ב-Codemagic והרץ workflow בשם:
   **Keter Reuven iOS App Store**

בסיום מוצלח ה-IPA יועלה אוטומטית ל-TestFlight, ולא יישלח עדיין ל-App Review.
