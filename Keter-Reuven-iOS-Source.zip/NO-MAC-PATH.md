# אין Mac? המסלול המומלץ

הפרויקט עצמו מוכן ל־Xcode, אבל build חתום ל־App Store חייב לרוץ בסביבת macOS.

אחרי שחשבון Apple Developer יהיה פעיל אפשר לבחור:

1. **שירות build בענן ל־iOS** — המסלול הפשוט ביותר בלי Mac מקומי.
2. **GitHub Actions עם runner של macOS** — אפשרי, אבל דורש הגדרת חתימה ו־App Store Connect API Key.
3. **Mac זמני/של חבר** — לפתוח Xcode, לבחור Team, להריץ Archive ולהעלות.

לכל האפשרויות נדרשים בסוף פרטי Apple Developer שלך. אין צורך לקנות iPhone או Mac רק בשביל ההכנה של הפרויקט.
