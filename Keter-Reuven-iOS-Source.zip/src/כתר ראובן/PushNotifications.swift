import UIKit
import UserNotifications
import WebKit

private var nativePushToken: String?

func handleSubscribeTouch(message _: WKScriptMessage) {
    // Topic subscriptions require a server-side APNs implementation.
    // Keep this bridge endpoint for forward compatibility with the web app.
    checkViewAndEvaluate(event: "push-subscribe", detail: "'server-setup-required'")
}

func returnPermissionResult(_ result: String) {
    checkViewAndEvaluate(event: "push-permission-request", detail: "'\(escapeJavaScriptString(result))'")
}

func returnPermissionState(_ state: String) {
    checkViewAndEvaluate(event: "push-permission-state", detail: "'\(escapeJavaScriptString(state))'")
}

func handlePushPermission() {
    guard nativePushEnabled else {
        returnPermissionResult("server-setup-required")
        return
    }

    UNUserNotificationCenter.current().getNotificationSettings { settings in
        switch settings.authorizationStatus {
        case .notDetermined:
            UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .badge, .sound]) { success, error in
                if let error = error {
                    print("Notification permission error: \(error.localizedDescription)")
                    returnPermissionResult("denied")
                    return
                }
                guard success else {
                    returnPermissionResult("denied")
                    return
                }
                returnPermissionResult("granted")
                DispatchQueue.main.async {
                    UIApplication.shared.registerForRemoteNotifications()
                }
            }
        case .denied:
            returnPermissionResult("denied")
        case .authorized, .ephemeral, .provisional:
            returnPermissionResult("granted")
            DispatchQueue.main.async {
                UIApplication.shared.registerForRemoteNotifications()
            }
        @unknown default:
            returnPermissionResult("unknown")
        }
    }
}

func handlePushState() {
    guard nativePushEnabled else {
        returnPermissionState("server-setup-required")
        return
    }

    UNUserNotificationCenter.current().getNotificationSettings { settings in
        switch settings.authorizationStatus {
        case .notDetermined: returnPermissionState("notDetermined")
        case .denied: returnPermissionState("denied")
        case .authorized: returnPermissionState("authorized")
        case .ephemeral: returnPermissionState("ephemeral")
        case .provisional: returnPermissionState("provisional")
        @unknown default: returnPermissionState("unknown")
        }
    }
}

func handlePushToken() {
    guard nativePushEnabled else {
        checkViewAndEvaluate(event: "push-token", detail: "'SERVER_SETUP_REQUIRED'")
        return
    }

    if let token = nativePushToken {
        checkViewAndEvaluate(event: "push-token", detail: "'\(token)'")
    } else {
        DispatchQueue.main.async {
            UIApplication.shared.registerForRemoteNotifications()
        }
    }
}

func storeNativePushToken(_ deviceToken: Data) {
    let token = deviceToken.map { String(format: "%02x", $0) }.joined()
    nativePushToken = token
    print("APNs device token registered")
    checkViewAndEvaluate(event: "push-token", detail: "'\(token)'")
}

func notifyPushTokenError(_ message: String) {
    checkViewAndEvaluate(
        event: "push-token",
        detail: "'ERROR: \(escapeJavaScriptString(message))'"
    )
}

func checkViewAndEvaluate(event: String, detail: String, retriesRemaining: Int = 20) {
    guard retriesRemaining > 0 else { return }

    DispatchQueue.main.async {
        guard let webView = webView else { return }
        if !webView.isHidden && !webView.isLoading {
            let safeEvent = escapeJavaScriptString(event)
            webView.evaluateJavaScript("this.dispatchEvent(new CustomEvent('\(safeEvent)', { detail: \(detail) }))")
        } else {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                checkViewAndEvaluate(event: event, detail: detail, retriesRemaining: retriesRemaining - 1)
            }
        }
    }
}

func sendPushToWebView(userInfo: [AnyHashable: Any]) {
    guard JSONSerialization.isValidJSONObject(userInfo),
          let jsonData = try? JSONSerialization.data(withJSONObject: userInfo),
          let json = String(data: jsonData, encoding: .utf8) else { return }
    checkViewAndEvaluate(event: "push-notification", detail: json)
}

func sendPushClickToWebView(userInfo: [AnyHashable: Any]) {
    guard JSONSerialization.isValidJSONObject(userInfo),
          let jsonData = try? JSONSerialization.data(withJSONObject: userInfo),
          let json = String(data: jsonData, encoding: .utf8) else { return }
    checkViewAndEvaluate(event: "push-notification-click", detail: json)
}

private func escapeJavaScriptString(_ value: String) -> String {
    value
        .replacingOccurrences(of: "\\", with: "\\\\")
        .replacingOccurrences(of: "'", with: "\\'")
        .replacingOccurrences(of: "\n", with: "\\n")
        .replacingOccurrences(of: "\r", with: "\\r")
}
