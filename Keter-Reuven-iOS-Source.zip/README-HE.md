# כתר ראובן — חבילת iOS מוכנה לשלב החתימה

## מצב החבילה

- שם אפליקציה: **כתר ראובן**
- Bundle ID: **il.co.keter-reuven.app**
- גרסה: **1.0**
- Build: **1**
- מינימום iOS/iPadOS: **15.0**
- יעד: **iPhone + iPad**
- Mac Catalyst: **כבוי**
- כתובת ראשית: **https://www.keter-reuven.co.il/**
- App Transport Security: **ללא חריגת HTTP כללית**
- Firebase/Google template: **הוסר**
- CocoaPods: **הוסר** — אין צורך ב־`pod install`
- Web Inspector ב־Release: **כבוי**
- Background audio: **פעיל** לטובת הרדיו/שיעורים
- Native Share: **פעיל** כגיבוי ל־`navigator.share`
- Push Native: **מוכן בקוד אך כבוי** עד לחיבור Apple Developer/APNs בצד השרת

## מה נשאר לפני TestFlight/App Store

1. לפתוח/להפעיל Apple Developer Program על שמך.
2. לפתוח את `src/כתר ראובן.xcworkspace` ב־Xcode 26 או חדש יותר.
3. לבחור Target **כתר ראובן** → Signing & Capabilities → Team → לבחור את החשבון שלך.
4. לוודא ש־Bundle Identifier נשאר `il.co.keter-reuven.app`.
5. להריץ קודם על iPhone אמיתי ולבדוק: פתיחה, ניווט, רדיו/אודיו ברקע, שיתוף, הורדות וקישורים.
6. Product → Archive → Distribute App → App Store Connect → Upload.
7. ב־App Store Connect להשלים תיאור, צילומי מסך, פרטיות, דירוג גיל ופרטי תמיכה.

## Push

לא להפעיל Push Native עדיין. הוא דורש App ID עם Push Notifications ומפתח APNs/Team ID, וכן התאמה קטנה בשרת כדי לשמור token ולשלוח דרך APNs. כל ההכנה בקוד קיימת ומפורטת ב־`PUSH-SETUP.md`.

## Universal Links

לא הופעלו עדיין Entitlements של Associated Domains, מפני שקובץ AASA דורש את Team ID של Apple. אפשר להוסיף אחרי פתיחת החשבון לפי `PUSH-SETUP.md` / ההערות שם.

## הערה חשובה ל־App Review

האפליקציה אינה מעטפת ריקה בלבד: קיימים רדיו ושיעורים, ספרייה, תפילות וזמנים, לימוד יומי, תהילים, שיתוף Native, הורדות ושמירת מצב. ברשומת ה־Review כדאי לציין במיוחד את הרדיו/שיעורים ואת יכולת ההאזנה ברקע.
