import Foundation
import CoreLocation
import WebKit
import UIKit

// Native CoreLocation bridge for the trusted Keter Reuven website.
// Uses When-In-Use authorization only and never transmits coordinates to third parties.
final class NativeCompassBridge: NSObject, CLLocationManagerDelegate {
    static let injectedJavaScript = #"""
(() => {
  'use strict';
  // Only expose native location to the app's trusted main-frame origin.
  if (location.protocol !== 'https:' || location.hostname !== 'www.keter-reuven.co.il') return;
  const handler = window.webkit?.messageHandlers?.['kr-native-compass'];
  if (!handler || window.__krNativeCompassInstalled) return;
  Object.defineProperty(window, '__krNativeCompassInstalled', { value: true });

  let nextId = 0;
  const requests = new Map();
  const watches = new Map();
  let permissionState = 'prompt';
  let hasRealOrientation = { value: false };
  window.addEventListener('deviceorientation', event => {
    if (event.isTrusted && (Number.isFinite(event.alpha) || Number.isFinite(event.webkitCompassHeading))) {
      hasRealOrientation.value = true;
    }
  }, {capture: true});
  const post = (action, id) => handler.postMessage(id == null ? {action} : {action, id: String(id)});
  const error = (code, message) => ({code, message, PERMISSION_DENIED: 1, POSITION_UNAVAILABLE: 2, TIMEOUT: 3});
  const successPosition = (data) => ({
    coords: {
      latitude: data.latitude, longitude: data.longitude, accuracy: data.accuracy,
      altitude: data.altitude ?? null, altitudeAccuracy: data.altitudeAccuracy ?? null,
      heading: data.course ?? null, speed: data.speed ?? null
    },
    timestamp: data.timestamp || Date.now()
  });
  const notify = (callback, value) => { if (typeof callback === 'function') { try { callback(value); } catch (e) { setTimeout(() => { throw e; }, 0); } } };
  const newId = () => String(++nextId);
  const optionsTimeout = (options) => {
    const ms = Number(options && options.timeout);
    return Number.isFinite(ms) && ms >= 0 ? ms : Infinity;
  };
  const getCurrentPosition = (onSuccess, onError, options = {}) => {
    if (typeof onSuccess !== 'function') throw new TypeError('getCurrentPosition requires a success callback');
    const id = newId();
    const item = {onSuccess, onError, timer: null};
    requests.set(id, item);
    const timeout = optionsTimeout(options);
    if (timeout !== Infinity) {
      item.timer = setTimeout(() => {
        if (!requests.has(id)) return;
        requests.delete(id);
        post('cancelLocation', id);
        notify(onError, error(3, 'Location request timed out'));
      }, timeout);
    }
    post('getLocation', id);
  };
  const watchPosition = (onSuccess, onError, options = {}) => {
    if (typeof onSuccess !== 'function') throw new TypeError('watchPosition requires a success callback');
    const id = newId();
    watches.set(id, {onSuccess, onError});
    post('watchLocation', id);
    return Number(id);
  };
  const clearWatch = (id) => {
    const key = String(id);
    if (watches.delete(key)) post('clearWatch', key);
  };
  const geo = Object.freeze({getCurrentPosition, watchPosition, clearWatch});
  // The existing website can keep using navigator.geolocation unchanged.
  try {
    Object.defineProperty(navigator, 'geolocation', { configurable: true, enumerable: true, get: () => geo });
  } catch (_) {
    try {
      const existing = navigator.geolocation;
      existing.getCurrentPosition = getCurrentPosition;
      existing.watchPosition = watchPosition;
      existing.clearWatch = clearWatch;
    } catch (_) { /* Named API remains available for website integration. */ }
  }

  function emitHeading(data) {
    window.dispatchEvent(new CustomEvent('kr-native-heading', { detail: data }));
    // Avoid duplicate/conflicting heading events if iOS already supplies them.
    if (hasRealOrientation.value) return;
    // Compatibility with compass implementations that use WebKit's compass heading.
    // Native CLLocation heading is clockwise from north; webkitCompassHeading uses that convention.
    for (const type of ['deviceorientation', 'deviceorientationabsolute']) {
      let event;
      try {
        event = new DeviceOrientationEvent(type, { alpha: (360 - data.heading) % 360, beta: null, gamma: null, absolute: true });
      } catch (_) {
        event = new Event(type);
      }
      try { Object.defineProperty(event, 'webkitCompassHeading', { value: data.heading }); } catch (_) {}
      try { Object.defineProperty(event, 'webkitCompassAccuracy', { value: data.accuracy }); } catch (_) {}
      window.dispatchEvent(event);
    }
  }
  window.__krNativeCompassOnMessage = (data) => {
    if (!data || typeof data !== 'object') return;
    if (data.type === 'authorization') {
      permissionState = data.state;
      window.dispatchEvent(new CustomEvent('kr-native-permission', {detail: {state: permissionState}}));
    } else if (data.type === 'location') {
      const position = successPosition(data);
      if (data.id != null) {
        const key = String(data.id);
        const item = requests.get(key);
        if (item) {
          requests.delete(key);
          if (item.timer != null) clearTimeout(item.timer);
          notify(item.onSuccess, position);
        }
      }
      if (data.watch === true) for (const item of watches.values()) notify(item.onSuccess, position);
      window.dispatchEvent(new CustomEvent('kr-native-location', {detail: position}));
    } else if (data.type === 'error') {
      const err = error(data.code || 2, data.message || 'Location unavailable');
      if (data.id != null) {
        const key = String(data.id);
        const item = requests.get(key);
        if (item) {
          requests.delete(key);
          if (item.timer != null) clearTimeout(item.timer);
          notify(item.onError, err);
        }
        const watcher = watches.get(key);
        if (watcher) notify(watcher.onError, err);
      }
      window.dispatchEvent(new CustomEvent('kr-native-error', { detail: err }));
    } else if (data.type === 'heading') emitHeading(data);
  };
  window.krNativeCompass = Object.freeze({
    getCurrentPosition, watchPosition, clearWatch,
    startHeading: () => post('startHeading'),
    stopHeading: () => post('stopHeading'),
    permissionState: () => permissionState
  });
  window.addEventListener('pagehide', () => post('stopAll'));
})();
"""#

    private let locationManager = CLLocationManager()
    private weak var webView: WKWebView?
    private var pendingRequests = Set<String>()
    private var watchers = Set<String>()
    private var headingRequested = false
    private var headingNeededFromLocation = false
    private var active = true

    override init() {
        super.init()
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.distanceFilter = 5
        locationManager.headingFilter = 1
        NotificationCenter.default.addObserver(self, selector: #selector(resignActive), name: UIApplication.willResignActiveNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(becomeActive), name: UIApplication.didBecomeActiveNotification, object: nil)
    }

    func attach(to view: WKWebView) {
        webView = view
    }

    // Called on top-level navigation; callbacks from the previous JS document are invalid.
    func reset() {
        pendingRequests.removeAll()
        watchers.removeAll()
        headingRequested = false
        headingNeededFromLocation = false
        locationManager.stopUpdatingLocation()
        locationManager.stopUpdatingHeading()
    }

    func updateHeadingOrientation() {
        guard let orientation = webView?.window?.windowScene?.interfaceOrientation else { return }
        switch orientation {
        case .portrait: locationManager.headingOrientation = .portrait
        case .portraitUpsideDown: locationManager.headingOrientation = .portraitUpsideDown
        case .landscapeLeft: locationManager.headingOrientation = .landscapeLeft
        case .landscapeRight: locationManager.headingOrientation = .landscapeRight
        default: break
        }
    }

    func handle(_ message: WKScriptMessage) {
        guard message.frameInfo.isMainFrame,
              message.frameInfo.securityOrigin.protocol == "https",
              message.frameInfo.securityOrigin.host == "www.keter-reuven.co.il",
              let payload = message.body as? [String: Any],
              let action = payload["action"] as? String else { return }

        let id = payload["id"] as? String
        switch action {
        case "getLocation", "watchLocation":
            guard let id = id, !id.isEmpty, id.count <= 40 else { return }
            if action == "getLocation" { pendingRequests.insert(id) }
            else { watchers.insert(id) }
            headingNeededFromLocation = true
            requireAuthorization()
        case "cancelLocation":
            if let id = id { pendingRequests.remove(id) }
            stopUnusedLocationUpdates()
        case "clearWatch":
            if let id = id { watchers.remove(id) }
            stopUnusedLocationUpdates()
        case "startHeading":
            headingRequested = true
            requireAuthorization()
        case "stopHeading":
            headingRequested = false
            locationManager.stopUpdatingHeading()
        case "stopAll":
            reset()
        default: break
        }
    }

    private func requireAuthorization() {
        guard CLLocationManager.locationServicesEnabled() else {
            failAll(code: 2, message: "Location services are disabled")
            return
        }
        switch locationManager.authorizationStatus {
        case .authorizedWhenInUse, .authorizedAlways:
            startAuthorizedServices()
        case .notDetermined:
            locationManager.requestWhenInUseAuthorization()
        case .denied, .restricted:
            failAll(code: 1, message: "Location permission denied. Enable it in iOS Settings.")
        @unknown default:
            failAll(code: 2, message: "Location authorization unavailable")
        }
    }

    private func startAuthorizedServices() {
        guard active else { return }
        if !watchers.isEmpty {
            locationManager.startUpdatingLocation()
        } else if !pendingRequests.isEmpty {
            locationManager.requestLocation()
        }
        // Compass screens normally ask for GPS first; start native heading then, too.
        if headingRequested || headingNeededFromLocation {
            if CLLocationManager.headingAvailable() {
                updateHeadingOrientation()
                locationManager.startUpdatingHeading()
            } else {
                emit(["type": "headingUnavailable"])
            }
        }
    }

    private func stopUnusedLocationUpdates() {
        if watchers.isEmpty {
            locationManager.stopUpdatingLocation()
        }
    }

    func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
        let state: String
        switch manager.authorizationStatus {
        case .authorizedWhenInUse, .authorizedAlways: state = "granted"
        case .denied, .restricted: state = "denied"
        default: state = "prompt"
        }
        emit(["type": "authorization", "state": state])
        if state == "granted" { startAuthorizedServices() }
        else if state == "denied" { failAll(code: 1, message: "Location permission denied") }
    }

    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let location = locations.last, location.horizontalAccuracy >= 0 else { return }
        var values: [String: Any] = [
            "type": "location",
            "latitude": location.coordinate.latitude,
            "longitude": location.coordinate.longitude,
            "accuracy": location.horizontalAccuracy,
            "timestamp": location.timestamp.timeIntervalSince1970 * 1000,
            "altitude": location.verticalAccuracy >= 0 ? location.altitude : NSNull() as Any,
            "altitudeAccuracy": location.verticalAccuracy >= 0 ? location.verticalAccuracy : NSNull() as Any,
            "course": location.course >= 0 ? location.course : NSNull() as Any,
            "speed": location.speed >= 0 ? location.speed : NSNull() as Any
        ]
        for id in pendingRequests {
            values["id"] = id
            values["watch"] = false
            emit(values)
        }
        pendingRequests.removeAll()
        if !watchers.isEmpty {
            values.removeValue(forKey: "id")
            values["watch"] = true
            emit(values)
        }
        stopUnusedLocationUpdates()
    }

    func locationManager(_ manager: CLLocationManager, didUpdateHeading heading: CLHeading) {
        let value = heading.trueHeading >= 0 ? heading.trueHeading : heading.magneticHeading
        guard value >= 0, value.isFinite else { return }
        let normalized = value.truncatingRemainder(dividingBy: 360)
        emit([
            "type": "heading",
            "heading": normalized >= 0 ? normalized : normalized + 360,
            "magneticHeading": heading.magneticHeading,
            "trueHeading": heading.trueHeading >= 0 ? heading.trueHeading : NSNull() as Any,
            "accuracy": heading.headingAccuracy,
            "timestamp": heading.timestamp.timeIntervalSince1970 * 1000
        ])
    }

    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        let nsError = error as NSError
        // Transient "location unknown" errors can resolve on the next GPS update.
        if nsError.domain == kCLErrorDomain && nsError.code == CLError.locationUnknown.rawValue { return }
        let code = (nsError.domain == kCLErrorDomain && nsError.code == CLError.denied.rawValue) ? 1 : 2
        failAll(code: code, message: error.localizedDescription)
    }

    private func failAll(code: Int, message: String) {
        for id in pendingRequests.union(watchers) {
            emit(["type": "error", "id": id, "code": code, "message": message])
        }
        pendingRequests.removeAll()
        if code == 1 {
            locationManager.stopUpdatingHeading()
            locationManager.stopUpdatingLocation()
        }
    }

    private func emit(_ payload: [String: Any]) {
        guard active, let webView = webView,
              let host = webView.url?.host, host == "www.keter-reuven.co.il",
              let data = try? JSONSerialization.data(withJSONObject: payload, options: [.fragmentsAllowed]),
              let json = String(data: data, encoding: .utf8) else { return }
        webView.evaluateJavaScript("window.__krNativeCompassOnMessage && window.__krNativeCompassOnMessage(\(json));", completionHandler: nil)
    }

    @objc private func resignActive() {
        active = false
        locationManager.stopUpdatingLocation()
        locationManager.stopUpdatingHeading()
    }

    @objc private func becomeActive() {
        active = true
        requireAuthorizationIfNeeded()
    }

    private func requireAuthorizationIfNeeded() {
        guard !pendingRequests.isEmpty || !watchers.isEmpty || headingRequested || headingNeededFromLocation else { return }
        requireAuthorization()
    }

    deinit { NotificationCenter.default.removeObserver(self) }
}
